'use client';

import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { 
  Users, MapPin, Phone, MessageCircle, Search, Plus, 
  Trash2, Edit, FileText, ChevronRight, AlertTriangle, User, Calendar,
  Briefcase, CheckCircle, Clock, XCircle, List, Repeat, CalendarDays,
  LayoutDashboard, Bell, StickyNote, Settings, Menu, Image as ImageIcon, Send, QrCode, Smartphone, RefreshCw,
  Download, Upload, FileSpreadsheet, Lock, Shield, Database, Instagram, LogOut, Wifi, WifiOff
} from 'lucide-react';
import { io, Socket } from 'socket.io-client';

// --- بيانات افتراضية (Mock Data) ---
const INITIAL_CITIES = [
  { id: 'city_1', name: 'بغداد' },
  { id: 'city_2', name: 'النجف الأشرف' },
  { id: 'city_3', name: 'البصرة' },
];

const INITIAL_CUSTOMERS = [
  {
    id: 'cust_1',
    name: 'أحمد محمود',
    phone: '07701234567',
    address: 'حي الجامعة، شارع الربيع',
    locationLink: 'https://maps.google.com/?q=33.3152,44.3661',
    cityIds: ['city_1'],
    reports: [
      { id: 'rep_1', title: 'زيارة أولى', content: 'تمت زيارة الزبون والاتفاق على المبادئ الأولية.', author: 'موظف المبيعات', date: '2023-10-25' },
    ]
  },
  {
    id: 'cust_2',
    name: 'شركة الأفق المحدودة',
    phone: '+9647809876543',
    address: 'المدينة القديمة، قرب المرقد',
    locationLink: 'https://maps.google.com/?q=31.9959,44.3146',
    cityIds: ['city_2', 'city_1'],
    reports: []
  }
];

const PERMISSIONS_LIST = [
  { id: 'viewCustomersAndCities', label: 'ظهور قسم الزبائن والمدن' },
  { id: 'addCustomer', label: 'إضافة زبون' },
  { id: 'deleteCustomer', label: 'حذف زبون' },
  { id: 'editCustomer', label: 'تعديل زبون' },
  { id: 'viewReports', label: 'الدخول لتقارير الزبائن' },
  { id: 'addReport', label: 'إضافة تقرير للزبائن' },
  { id: 'deleteReport', label: 'حذف تقرير' },
  { id: 'addCity', label: 'إضافة مدينة' },
  { id: 'deleteCity', label: 'حذف مدينة' },
  { id: 'viewTasksSection', label: 'ظهور قسم المهام' },
  { id: 'addTask', label: 'إضافة مهمة' },
  { id: 'deleteTask', label: 'حذف مهمة' },
  { id: 'delayTask', label: 'تأجيل مهمة' },
  { id: 'cancelTask', label: 'إلغاء مهمة' },
  { id: 'viewWhatsappSection', label: 'اظهار قسم الواتساب' },
  { id: 'connectWhatsapp', label: 'ربط حساب واتساب' },
  { id: 'disconnectWhatsapp', label: 'إلغاء ربط واتساب' },
  { id: 'viewRemindersSection', label: 'ظهور قسم التذكيرات' },
  { id: 'addReminder', label: 'إضافة تذكير' },
  { id: 'deleteReminder', label: 'حذف تذكير' },
  { id: 'viewAllReminders', label: 'رؤية جميع التذكيرات' },
  { id: 'viewNotesSection', label: 'ظهور قسم الملاحظات' },
  { id: 'addNote', label: 'إضافة ملاحظة' },
  { id: 'deleteNote', label: 'حذف ملاحظة' },
  { id: 'viewSettings', label: 'الدخول إلى الإعدادات' },
  { id: 'addUser', label: 'إضافة مستخدم' },
  { id: 'deleteUser', label: 'حذف مستخدم' },
  { id: 'editUser', label: 'تعديل على مستخدم' },
  { id: 'makeBackup', label: 'عمل نسخة احتياطية' },
  { id: 'restoreBackup', label: 'رفع نسخة احتياطية' },
  { id: 'importCustomers', label: 'استيراد زبائن' },
];
const ALL_PERMS = PERMISSIONS_LIST.map(p => p.id);

const INITIAL_EMPLOYEES = [
  { id: 'emp_1', name: 'مدير النظام', phone: '07700000000', password: '123', role: 'manager', permissions: ALL_PERMS },
  { id: 'emp_2', name: 'أحمد علي (موظف)', phone: '07700000001', password: '123', role: 'employee', permissions: ['viewCustomersAndCities', 'viewTasksSection'] },
  { id: 'emp_3', name: 'سارة محمد (موظف)', phone: '07700000002', password: '123', role: 'employee', permissions: ['viewCustomersAndCities'] },
];

const INITIAL_TASKS = [
  { id: 't_1', employeeId: 'emp_1', title: 'مراجعة حسابات الشهر', details: 'مراجعة كاملة مع قسم الحسابات', date: new Date().toISOString().split('T')[0], isFullDay: true, status: 'active' },
  { id: 't_2', employeeId: 'emp_2', title: 'زيارة عميل مهم', details: 'زيارة شركة الأفق', date: '2023-10-01', isFullDay: false, startTime: '10:00', endTime: '12:00', status: 'active' },
];

const INITIAL_RECURRING_TASKS = [
  { id: 'rt_1', employeeId: 'emp_2', title: 'اجتماع الصباح', details: 'اجتماع يومي لفريق المبيعات', daysOfWeek: ['0', '1', '2', '3', '4'], isFullDay: false, startTime: '08:00', endTime: '09:00' }
];

const INITIAL_REMINDERS = [
  {
    id: 'rem_1',
    title: 'تجديد اشتراك الإنترنت',
    details: 'يرجى التأكد من تجديد اشتراك الشركة قبل انقطاع الخدمة.',
    employeeIds: ['emp_1', 'emp_2'],
    date: new Date().toISOString().split('T')[0],
    isFullDay: true,
    startTime: '',
    endTime: '',
    completionType: 'single',
    completions: []
  }
];

const INITIAL_NOTES = [
  { id: 'note_1', content: 'يجب التأكد من تحديث أرقام هواتف الزبائن في محافظة البصرة بشكل دوري.', author: 'مدير النظام', date: '2023-11-01' },
  { id: 'note_2', content: 'تم تأجيل اجتماع المبيعات الأسبوع القادم إلى يوم الخميس بدلاً من الأربعاء.', author: 'أحمد علي (موظف)', date: '2023-11-02' }
];

export default function Home() {
  // --- Auth States ---
  const [currentUser, setCurrentUser] = useState(null);
  const CURRENT_USER = currentUser; // تم التعريف هنا لتجنب خطأ ReferenceError

  const [loginPhone, setLoginPhone] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  // --- States ---
  const [employeesList, setEmployeesList] = useState(INITIAL_EMPLOYEES);
  const EMPLOYEES = employeesList;

  // --- Dynamic Permissions ---
  const hasPerm = (perm) => CURRENT_USER?.permissions.includes(perm);
  const USER_PERMISSIONS = CURRENT_USER ? {
    viewCustomersAndCities: hasPerm('viewCustomersAndCities'),
    addCustomer: hasPerm('addCustomer'),
    deleteCustomer: hasPerm('deleteCustomer'),
    editCustomer: hasPerm('editCustomer'),
    viewReports: hasPerm('viewReports'),
    addReport: hasPerm('addReport'),
    deleteReport: hasPerm('deleteReport'),
    addCity: hasPerm('addCity'),
    deleteCity: hasPerm('deleteCity'),
    editAdminNote: CURRENT_USER.role === 'manager',
    viewTasksSection: hasPerm('viewTasksSection'),
    addTask: hasPerm('addTask'),
    deleteTask: hasPerm('deleteTask'),
    delayTask: hasPerm('delayTask'),
    cancelTask: hasPerm('cancelTask'),
    viewWhatsappSection: hasPerm('viewWhatsappSection'),
    manageWhatsappConnection: CURRENT_USER.role === 'manager',
    connectWhatsapp: hasPerm('connectWhatsapp'),
    disconnectWhatsapp: hasPerm('disconnectWhatsapp'),
    viewRemindersSection: hasPerm('viewRemindersSection'),
    addReminder: hasPerm('addReminder'),
    deleteReminder: hasPerm('deleteReminder'),
    viewAllReminders: hasPerm('viewAllReminders'),
    viewNotesSection: hasPerm('viewNotesSection'),
    addNote: hasPerm('addNote'),
    deleteNote: hasPerm('deleteNote'),
    viewSettings: hasPerm('viewSettings'),
    addUser: hasPerm('addUser'),
    deleteUser: hasPerm('deleteUser'),
    editUser: hasPerm('editUser'),
    makeBackup: hasPerm('makeBackup'),
    restoreBackup: hasPerm('restoreBackup'),
    importCustomers: hasPerm('importCustomers'),
  } : {};

  const [appSection, setAppSection] = useState('dashboard');
  const [tasksSubSection, setTasksSubSection] = useState('myTasks');
  const [whatsappSubSection, setWhatsappSubSection] = useState('send');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('customers');
  const [cities, setCities] = useState(INITIAL_CITIES);
  const [customers, setCustomers] = useState(INITIAL_CUSTOMERS);
  
  // Navigation States
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedCity, setSelectedCity] = useState(null);

  // Search States
  const [customerSearch, setCustomerSearch] = useState('');
  const [cityCustomerSearch, setCityCustomerSearch] = useState('');
  const [reportSearch, setReportSearch] = useState('');

  // Modals States
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [isAddCityOpen, setIsAddCityOpen] = useState(false);
  const [isAddReportOpen, setIsAddReportOpen] = useState(false);
  const [deleteCityTransfer, setDeleteCityTransfer] = useState(null);

  // Tasks States
  const [tasks, setTasks] = useState(INITIAL_TASKS);
  const [recurringTasks, setRecurringTasks] = useState(INITIAL_RECURRING_TASKS);
  const [selectedTaskEmployee, setSelectedTaskEmployee] = useState(null); 
  const [taskActiveTab, setTaskActiveTab] = useState('active');
  const [taskDateFilter, setTaskDateFilter] = useState(new Date().toISOString().split('T')[0]);
  
  // Tasks Modals
  const [isAddTaskOpen, setIsAddTaskOpen] = useState(false);
  const [taskActionModal, setTaskActionModal] = useState(null);

  // Global Admin Note (Mock)
  const [adminNote, setAdminNote] = useState('يرجى التأكد من تحديث بيانات الزبون بشكل دوري والتواصل معه أسبوعياً.');

  // --- WhatsApp & Settings States ---
  const [waStatus, setWaStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  const [waPhone, setWaPhone] = useState('');
  const [waQrCode, setWaQrCode] = useState('');
  const [waQrTimer, setWaQrTimer] = useState(20);
  const [waLoading, setWaLoading] = useState(false);
  const [waSocketConnected, setWaSocketConnected] = useState(false);
  const [isSendingMessages, setIsSendingMessages] = useState(false);
  const [sendProgress, setSendProgress] = useState<{ current: number; total: number } | null>(null);
  const waSocketRef = useRef<Socket | null>(null);
  
  // Send Message States
  const [waTargetType, setWaTargetType] = useState('all');
  const [waSelectedCity, setWaSelectedCity] = useState('');
  const [waSpecificCustomers, setWaSpecificCustomers] = useState([]);
  const [waCustomerSearch, setWaCustomerSearch] = useState('');
  const [waSpecificEmployees, setWaSpecificEmployees] = useState([]);
  const [waMessageText, setWaMessageText] = useState('');
  const [waMessageImage, setWaMessageImage] = useState(null);
  
  const [scheduledMessages, setScheduledMessages] = useState([]);
  const [sendLogs, setSendLogs] = useState<Array<{id: string; targetName: string; status: string; error: string}>>([]);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);

  // --- Settings States ---
  const [settingsTab, setSettingsTab] = useState('users');
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [lastBackup, setLastBackup] = useState({ time: '2023-11-01 10:30 AM', user: 'مدير النظام' });
  const [waMessageDelay, setWaMessageDelay] = useState(5);
  const [importCityId, setImportCityId] = useState('');

  // --- Reminders States ---
  const [reminders, setReminders] = useState(INITIAL_REMINDERS);
  const [remindersTab, setRemindersTab] = useState('today');
  const [isAddReminderOpen, setIsAddReminderOpen] = useState(false);
  const [reminderCompletionModal, setReminderCompletionModal] = useState(null);

  // --- Notes States ---
  const [notes, setNotes] = useState(INITIAL_NOTES);
  const [noteSearch, setNoteSearch] = useState('');
  const [newNoteText, setNewNoteText] = useState('');

  // --- Effects ---
  
  // WhatsApp Real Connection via Socket.IO
  useEffect(() => {
    // Connect to WhatsApp Real Server on port 3005
    // Use the current host with port 3005 for the WhatsApp server
    const socketHost = typeof window !== 'undefined' 
      ? `${window.location.protocol}//${window.location.hostname}:3005`
      : 'http://localhost:3005';
    
    console.log('Connecting to WhatsApp server at:', socketHost);
    
    const socket = io(socketHost, {
      transports: ['websocket', 'polling'],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 2000,
      timeout: 15000
    });

    waSocketRef.current = socket;

    socket.on('connect', () => {
      console.log('WhatsApp server connected');
      setWaSocketConnected(true);
      // Request current status when connected
      socket.emit('get-qr');
    });

    socket.on('disconnect', () => {
      console.log('WhatsApp server disconnected');
      setWaSocketConnected(false);
    });

    // Handle session status updates
    socket.on('session-status', (data: {
      status: 'disconnected' | 'connecting' | 'connected';
      phoneNumber?: string | null;
      qrCode?: string | null;
    }) => {
      console.log('Session status:', data);
      setWaStatus(data.status);
      if (data.phoneNumber) setWaPhone(data.phoneNumber);
      if (data.qrCode) setWaQrCode(data.qrCode);
      if (data.status === 'connected') {
        setWaQrCode('');
      }
    });

    // Handle QR code updates
    socket.on('qr-code', (data: { qrCode: string; timestamp: number }) => {
      console.log('QR code received from server');
      setWaQrCode(data.qrCode);
      setWaQrTimer(20);
      setWaStatus('connecting');
    });

    // Handle bulk send progress
    socket.on('bulk-send-progress', (data: {
      current: number;
      total: number;
      recipient: { phone: string; name: string };
      status: 'sent' | 'failed';
    }) => {
      setSendProgress({ current: data.current, total: data.total });
    });

    // Handle bulk send complete
    socket.on('bulk-send-complete', (data: {
      total: number;
      successful: number;
      failed: number;
      results: Array<{ phone: string; name: string; status: string; error?: string }>;
    }) => {
      console.log('Bulk send complete:', data);
      setIsSendingMessages(false);
      setSendProgress(null);
      
      const newLogs = data.results.map((r, idx) => ({
        id: `log_${Date.now()}_${idx}`,
        targetName: r.name,
        status: r.status === 'sent' ? 'success' : 'failed',
        error: r.error || ''
      }));
      setSendLogs(newLogs);
    });

    return () => {
      socket.disconnect();
      waSocketRef.current = null;
    };
  }, []);

  // QR Code timer countdown - auto refresh QR
  useEffect(() => {
    let countdown: NodeJS.Timeout | null = null;
    if (waStatus === 'connecting' && waQrCode) {
      countdown = setInterval(() => {
        setWaQrTimer((prev) => {
          if (prev <= 1) {
            return 20;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (countdown) clearInterval(countdown);
    };
  }, [waStatus, waQrCode]);

  // --- Login Handler ---
  const handleLogin = (e) => {
    e.preventDefault();
    const user = employeesList.find(emp => emp.phone === loginPhone && emp.password === loginPassword);
    if (user) {
      setCurrentUser(user);
      setLoginError('');
      setLoginPhone('');
      setLoginPassword('');
    } else {
      setLoginError('رقم الهاتف أو كلمة المرور غير صحيحة.');
    }
  };

  // --- Handlers ---
  
  const handleAddCustomer = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const selectedCityIds = formData.getAll('cityIds');
    
    if (selectedCityIds.length === 0) {
      alert("الرجاء اختيار مدينة واحدة على الأقل");
      return;
    }

    const newCustomer = {
      id: `cust_${Date.now()}`,
      name: formData.get('name'),
      phone: formData.get('phone'),
      address: formData.get('address'),
      locationLink: formData.get('locationLink'),
      cityIds: selectedCityIds,
      reports: []
    };

    setCustomers([newCustomer, ...customers]);
    setIsAddCustomerOpen(false);
  };

  const handleDeleteCustomer = (id) => {
    if(window.confirm('هل أنت متأكد من حذف هذا الزبون؟')) {
      setCustomers(customers.filter(c => c.id !== id));
      if(selectedCustomer?.id === id) setSelectedCustomer(null);
    }
  };

  const handleAddCity = (e) => {
    e.preventDefault();
    const name = new FormData(e.target).get('name');
    setCities([...cities, { id: `city_${Date.now()}`, name }]);
    setIsAddCityOpen(false);
  };

  const handleDeleteCityRequest = (cityId) => {
    const affectedCustomers = customers.filter(c => c.cityIds.includes(cityId));
    
    if (affectedCustomers.length > 0) {
      setDeleteCityTransfer({ cityId, affectedCustomers });
    } else {
      if(window.confirm('هل أنت متأكد من حذف هذه المدينة؟')) {
        setCities(cities.filter(c => c.id !== cityId));
      }
    }
  };

  const handleTransferAndDeleteCity = (e) => {
    e.preventDefault();
    const newCityId = new FormData(e.target).get('newCityId');
    const oldCityId = deleteCityTransfer.cityId;

    const updatedCustomers = customers.map(cust => {
      if (cust.cityIds.includes(oldCityId)) {
        let newCityIds = cust.cityIds.filter(id => id !== oldCityId);
        if (!newCityIds.includes(newCityId)) {
          newCityIds.push(newCityId);
        }
        return { ...cust, cityIds: newCityIds };
      }
      return cust;
    });

    setCustomers(updatedCustomers);
    setCities(cities.filter(c => c.id !== oldCityId));
    setDeleteCityTransfer(null);
  };

  const handleAddReport = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const newReport = {
      id: `rep_${Date.now()}`,
      title: formData.get('title'),
      content: formData.get('content'),
      author: CURRENT_USER?.name || 'مستخدم',
      date: new Date().toISOString().split('T')[0]
    };

    const updatedCustomers = customers.map(c => 
      c.id === selectedCustomer.id ? { ...c, reports: [newReport, ...c.reports] } : c
    );
    
    setCustomers(updatedCustomers);
    setSelectedCustomer({ ...selectedCustomer, reports: [newReport, ...selectedCustomer.reports] });
    setIsAddReportOpen(false);
  };

  const handleDeleteReport = (reportId) => {
    if(window.confirm('هل أنت متأكد من حذف التقرير؟')) {
      const updatedCustomers = customers.map(c => {
        if (c.id === selectedCustomer.id) {
          return { ...c, reports: c.reports.filter(r => r.id !== reportId) };
        }
        return c;
      });
      setCustomers(updatedCustomers);
      setSelectedCustomer({ ...selectedCustomer, reports: selectedCustomer.reports.filter(r => r.id !== reportId) });
    }
  };

  const handleAddTask = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const title = formData.get('title');
    const details = formData.get('details');
    const isRecurring = formData.get('isRecurring') === 'on';
    const isFullDay = formData.get('isFullDay') === 'on';
    const employeeId = formData.get('employeeId') || CURRENT_USER?.id;
    
    if (isRecurring) {
      const daysOfWeek = formData.getAll('daysOfWeek');
      if (daysOfWeek.length === 0) return alert('الرجاء اختيار يوم واحد على الأقل للمهمة المتكررة');
      const newRT = {
        id: `rt_${Date.now()}`, employeeId, title, details, daysOfWeek,
        isFullDay, startTime: formData.get('startTime'), endTime: formData.get('endTime')
      };
      setRecurringTasks([...recurringTasks, newRT]);
    } else {
      const newTask = {
        id: `t_${Date.now()}`, employeeId, title, details,
        date: formData.get('date'), isFullDay, startTime: formData.get('startTime'), endTime: formData.get('endTime'),
        status: 'active'
      };
      setTasks([...tasks, newTask]);
    }
    setIsAddTaskOpen(false);
  };

  const handleTaskAction = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const { type, task } = taskActionModal;
    
    let updatedTask = { ...task };
    const isVirtual = task.isVirtual;
    
    if (type === 'complete') {
      updatedTask.status = 'completed';
      updatedTask.completionDetails = formData.get('completionDetails');
    } else if (type === 'delay') {
      updatedTask.status = 'delayed';
      updatedTask.delayReason = formData.get('delayReason');
      updatedTask.date = formData.get('newDate');
      updatedTask.startTime = formData.get('newStartTime');
      updatedTask.endTime = formData.get('newEndTime');
      updatedTask.isFullDay = formData.get('isFullDay') === 'on';
    } else if (type === 'cancel') {
      updatedTask.status = 'canceled';
      updatedTask.cancelReason = formData.get('cancelReason');
      updatedTask.canceledBy = CURRENT_USER?.name;
    } else if (type === 'reschedule') {
      updatedTask.status = 'active';
      updatedTask.date = formData.get('newDate');
      updatedTask.startTime = formData.get('newStartTime');
      updatedTask.endTime = formData.get('newEndTime');
      updatedTask.isFullDay = formData.get('isFullDay') === 'on';
    }

    if (isVirtual) {
      delete updatedTask.isVirtual;
      delete updatedTask.daysOfWeek;
      updatedTask.id = `t_${Date.now()}`;
      setTasks([...tasks, updatedTask]);
    } else {
      setTasks(tasks.map(t => t.id === task.id ? updatedTask : t));
    }
    setTaskActionModal(null);
  };

  const handleDeleteRecurringTask = (id) => {
     if(window.confirm('هل أنت متأكد من إلغاء تكرار هذه المهمة؟')) {
        setRecurringTasks(recurringTasks.filter(rt => rt.id !== id));
     }
  };

  const handleConnectWhatsapp = async () => {
    setWaLoading(true);
    try {
      if (waSocketRef.current && waSocketConnected) {
        // Request QR code from server
        waSocketRef.current.emit('get-qr');
        setWaStatus('connecting');
      } else {
        alert('غير متصل بسيرفر واتساب. يرجى الانتظار أو تحديث الصفحة.');
      }
    } catch (error) {
      console.error('Error connecting WhatsApp:', error);
      alert('حدث خطأ أثناء الاتصال.');
    } finally {
      setWaLoading(false);
    }
  };
  
  const handleDisconnectWhatsapp = async () => {
    if(window.confirm('هل أنت متأكد من إلغاء ربط الحساب الحالي؟')) {
      if (waSocketRef.current && waSocketConnected) {
        waSocketRef.current.emit('disconnect-session');
      }
      setWaStatus('disconnected');
      setWaPhone('');
      setWaQrCode('');
    }
  };
  
  const handleSimulateScan = () => {
    const phoneNumber = prompt('أدخل رقم الهاتف للمحاكاة:', '+9647800000000');
    if (phoneNumber && waSocketRef.current && waSocketConnected) {
      waSocketRef.current.emit('simulate-connect', { phoneNumber });
    }
  };

  const executeSendWhatsapp = async (isScheduled = false, scheduleDate = null) => {
    if (!waMessageText && !waMessageImage) return alert('الرجاء كتابة رسالة أو إرفاق صورة.');
    
    let targets = [];
    let targetLabel = '';

    if (waTargetType === 'all') {
      targets = customers.map(c => ({ id: c.id, name: c.name, phone: c.phone, type: 'زبون' }));
      targetLabel = 'جميع الزبائن';
    } else if (waTargetType === 'city') {
      if (!waSelectedCity) return alert('الرجاء اختيار المدينة.');
      const cityCusts = customers.filter(c => c.cityIds.includes(waSelectedCity));
      targets = cityCusts.map(c => ({ id: c.id, name: c.name, phone: c.phone, type: 'زبون' }));
      targetLabel = `مدينة: ${cities.find(c=>c.id === waSelectedCity)?.name}`;
    } else if (waTargetType === 'specific_customers') {
      if (waSpecificCustomers.length === 0) return alert('الرجاء اختيار زبون واحد على الأقل.');
      targets = customers.filter(c => waSpecificCustomers.includes(c.id)).map(c => ({ id: c.id, name: c.name, phone: c.phone, type: 'زبون' }));
      targetLabel = `زبائن محددين (${targets.length})`;
    } else if (waTargetType === 'employees') {
      if (waSpecificEmployees.length === 0) return alert('الرجاء اختيار موظف واحد على الأقل.');
      targets = EMPLOYEES.filter(e => waSpecificEmployees.includes(e.id)).map(e => ({ id: e.id, name: e.name, phone: 'N/A', type: 'موظف' }));
      targetLabel = `موظفين محددين (${targets.length})`;
    }

    if (targets.length === 0) return alert('لا يوجد مستلمين مطابقين للاختيار.');

    if (isScheduled && scheduleDate) {
      const newScheduled = {
        id: `sch_${Date.now()}`,
        text: waMessageText,
        hasImage: !!waMessageImage,
        targetLabel,
        targets,
        scheduleDate,
        createdAt: new Date().toISOString()
      };
      setScheduledMessages([newScheduled, ...scheduledMessages]);
      setIsScheduleModalOpen(false);
      alert('تمت جدولة الرسالة بنجاح!');
    } else {
      // Check if WhatsApp is connected
      if (waStatus !== 'connected') {
        const proceed = confirm('الواتساب غير متصل حالياً. هل تريد الإرسال في وضع المحاكاة؟');
        if (!proceed) return;
      }

      setIsSendingMessages(true);
      setSendProgress({ current: 0, total: targets.length });

      // Use WebSocket for sending if connected
      if (waSocketRef.current && waSocketConnected && waStatus === 'connected') {
        waSocketRef.current.emit('send-bulk-messages', {
          recipients: targets.map(t => ({ phone: t.phone, name: t.name })),
          message: waMessageText,
          imageUrl: waMessageImage ? URL.createObjectURL(waMessageImage) : undefined
        });
      } else {
        // Fallback: simulation mode
        const newLogs = targets.map((t, idx) => ({
          id: `log_${Date.now()}_${idx}`,
          targetName: t.name,
          status: Math.random() > 0.1 ? 'success' : 'failed',
          error: Math.random() > 0.1 ? '' : 'الرقم غير مسجل في واتساب'
        }));
        setSendLogs(newLogs);
        setIsSendingMessages(false);
        setSendProgress(null);
      }
    }
    
    setWaMessageText('');
    setWaMessageImage(null);
  };

  const handleCancelScheduledMsg = (id) => {
    if(window.confirm('هل أنت متأكد من إلغاء هذه الرسالة المجدولة؟')) {
      setScheduledMessages(scheduledMessages.filter(m => m.id !== id));
    }
  };

  const handleAddReminder = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const title = formData.get('title');
    const details = formData.get('details');
    const employeeIds = formData.getAll('employeeIds');
    const isFullDay = formData.get('isFullDay') === 'on';
    const completionType = formData.get('completionType'); 
    
    if (employeeIds.length === 0) return alert('الرجاء اختيار موظف واحد على الأقل.');

    const newReminder = {
      id: `rem_${Date.now()}`,
      title,
      details,
      employeeIds,
      date: formData.get('date'),
      isFullDay,
      startTime: formData.get('startTime'),
      endTime: formData.get('endTime'),
      completionType,
      completions: []
    };

    setReminders([...reminders, newReminder]);
    setIsAddReminderOpen(false);
    alert('تم إضافة التذكير، وتم إرسال إشعار عبر الواتساب للموظفين المشمولين بتفاصيل التذكير.');
  };

  const handleCompleteReminder = (e) => {
    e.preventDefault();
    const details = new FormData(e.target).get('completionDetails');
    const { reminder } = reminderCompletionModal;

    const newCompletion = {
      employeeId: CURRENT_USER?.id,
      details,
      date: new Date().toISOString().split('T')[0]
    };

    const updatedReminders = reminders.map(r => {
      if (r.id === reminder.id) {
        return { ...r, completions: [...r.completions, newCompletion] };
      }
      return r;
    });

    setReminders(updatedReminders);
    setReminderCompletionModal(null);
  };

  const handleDeleteReminder = (id) => {
    if(window.confirm('هل أنت متأكد من حذف هذا التذكير؟')) {
      setReminders(reminders.filter(r => r.id !== id));
    }
  };

  const handleAddNote = (e) => {
    e.preventDefault();
    if (!newNoteText.trim()) return;
    const newNote = {
      id: `note_${Date.now()}`,
      content: newNoteText,
      author: CURRENT_USER?.name,
      date: new Date().toISOString().split('T')[0]
    };
    setNotes([newNote, ...notes]);
    setNewNoteText('');
  };

  const handleDeleteNote = (id) => {
    if(window.confirm('هل أنت متأكد من حذف هذه الملاحظة؟')) {
      setNotes(notes.filter(n => n.id !== id));
    }
  };

  const handleSaveUser = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const selectedPerms = formData.getAll('permissions');
    
    const userData = {
      name: formData.get('name'),
      phone: formData.get('phone'),
      password: formData.get('password'),
      role: formData.get('role'),
      permissions: selectedPerms
    };

    if (editingUser) {
      setEmployeesList(employeesList.map(emp => emp.id === editingUser.id ? { ...emp, ...userData } : emp));
    } else {
      setEmployeesList([...employeesList, { id: `emp_${Date.now()}`, ...userData }]);
    }
    setIsUserModalOpen(false);
    setEditingUser(null);
  };

  const handleDeleteUser = (id) => {
    if(window.confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
      setEmployeesList(employeesList.filter(emp => emp.id !== id));
    }
  };

  const handleMakeBackup = () => {
    setLastBackup({ time: new Date().toLocaleString(), user: CURRENT_USER?.name || 'مجهول' });
    alert('تم تنزيل النسخة الاحتياطية بنجاح.');
  };

  const handleRestoreBackup = (e) => {
    if(e.target.files.length > 0) {
      alert('تم رفع النسخة الاحتياطية واستعادة البيانات بنجاح.');
    }
  };

  const handleImportCustomers = (e) => {
    e.preventDefault();
    if (!importCityId) return alert('الرجاء اختيار المدينة أولاً.');
    
    const fileInput = document.getElementById('importFile');
    if (!fileInput.files.length) return alert('الرجاء اختيار ملف إكسل.');

    alert('تم استيراد الزبائن بنجاح إلى المدينة المحددة!');
    setCustomers([{
      id: `cust_${Date.now()}`,
      name: 'زبون مستورد',
      phone: '07700000000',
      address: 'عنوان مستورد',
      locationLink: '',
      cityIds: [importCityId],
      reports: []
    }, ...customers]);
    
    setImportCityId('');
    fileInput.value = '';
  };

  // --- Derived Data ---
  const getProcessedTasksForEmployee = (empId, filterDate) => {
    if (!empId) return [];
    const today = new Date().toISOString().split('T')[0];
    const concreteTasks = tasks.filter(t => t.employeeId === empId);
    
    const virtualTasks = [];
    if (filterDate) {
      const dayOfWeek = new Date(filterDate).getDay().toString();
      const empRecurring = recurringTasks.filter(rt => rt.employeeId === empId && rt.daysOfWeek.includes(dayOfWeek));
      
      empRecurring.forEach(rt => {
         const exists = concreteTasks.some(ct => ct.title === rt.title && ct.date === filterDate);
         if (!exists) {
            virtualTasks.push({ ...rt, date: filterDate, status: 'active', isVirtual: true });
         }
      });
    }
    
    const allEmpTasks = [...concreteTasks, ...virtualTasks];
    allEmpTasks.forEach(t => {
       if (t.status === 'active' && t.date < today) {
          t.status = 'pending';
       }
    });

    return allEmpTasks;
  };

  const currentDashboardTasks = selectedTaskEmployee 
    ? getProcessedTasksForEmployee(selectedTaskEmployee.id, taskDateFilter)
    : (CURRENT_USER ? getProcessedTasksForEmployee(CURRENT_USER.id, taskDateFilter) : []);

  const filteredDashboardTasks = currentDashboardTasks.filter(t => {
    if (taskActiveTab === 'all') return true;
    if (taskActiveTab === 'active') return t.status === 'active' && t.date === taskDateFilter;
    if (taskActiveTab === 'completed') return t.status === 'completed' && t.date === taskDateFilter;
    return t.status === taskActiveTab;
  });

  const filteredCustomers = useMemo(() => {
    return customers.filter(c => 
      c.name.includes(customerSearch) || 
      c.phone.includes(customerSearch) || 
      c.address.includes(customerSearch)
    );
  }, [customers, customerSearch]);

  const cityFilteredCustomers = useMemo(() => {
    if (!selectedCity) return [];
    return customers
      .filter(c => c.cityIds.includes(selectedCity.id))
      .filter(c => 
        c.name.includes(cityCustomerSearch) || 
        c.phone.includes(cityCustomerSearch) || 
        c.address.includes(cityCustomerSearch)
      );
  }, [customers, selectedCity, cityCustomerSearch]);

  const filteredNotes = useMemo(() => {
    if (!noteSearch.trim()) return notes;
    return notes.filter(n => n.content.includes(noteSearch));
  }, [notes, noteSearch]);


  // --- Components ---
  const CustomerCard = ({ customer }) => (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div 
          className="cursor-pointer flex-1"
          onClick={() => setSelectedCustomer(customer)}
        >
          <h3 className="text-lg font-bold text-gray-800">{customer.name}</h3>
          <p className="text-sm text-gray-500 mt-1 flex items-center gap-1">
            <MapPin size={14} /> {customer.address}
          </p>
        </div>
        {USER_PERMISSIONS.deleteCustomer && (
          <button onClick={() => handleDeleteCustomer(customer.id)} className="text-red-500 hover:bg-red-50 p-2 rounded-lg">
            <Trash2 size={18} />
          </button>
        )}
      </div>
      
      <div className="flex gap-2 border-t pt-3 mt-2">
        <a href={`tel:${customer.phone}`} className="flex-1 flex justify-center items-center gap-2 bg-blue-50 text-blue-600 p-2 rounded-lg hover:bg-blue-100 transition">
          <Phone size={16} /> <span className="text-sm font-medium">اتصال</span>
        </a>
        <a href={`https://wa.me/${customer.phone.replace(/[^0-9]/g, '')}`} target="_blank" rel="noreferrer" className="flex-1 flex justify-center items-center gap-2 bg-green-50 text-green-600 p-2 rounded-lg hover:bg-green-100 transition">
          <MessageCircle size={16} /> <span className="text-sm font-medium">واتساب</span>
        </a>
        {customer.locationLink && (
          <a href={customer.locationLink} target="_blank" rel="noreferrer" className="flex-1 flex justify-center items-center gap-2 bg-gray-50 text-gray-600 p-2 rounded-lg hover:bg-gray-100 transition">
            <MapPin size={16} /> <span className="text-sm font-medium">الموقع</span>
          </a>
        )}
      </div>
    </div>
  );

  // --- Render logic ---

  if (!CURRENT_USER) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden" dir="rtl">
        <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-red-600/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-blue-600/10 rounded-full blur-3xl"></div>

        <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col relative z-10">
          <div className="p-10 flex flex-col items-center text-center border-b border-white/10">
            <h1 className="text-5xl font-black tracking-widest text-white mb-2 font-mono" style={{ fontFamily: "'Courier New', Courier, monospace", textShadow: '0 2px 10px rgba(0,0,0,0.5)' }}>
              AL-<span className="text-red-500">B</span>ASEEM<br/>
            </h1>
            <span className="text-xl text-slate-400 tracking-widest uppercase font-bold mt-1" style={{ fontFamily: "'Courier New', Courier, monospace" }}>
              General Trading
            </span>
          </div>
          
          <form onSubmit={handleLogin} className="p-8 space-y-6">
            {loginError && <div className="bg-red-500/10 border border-red-500/50 text-red-400 p-3 rounded-xl text-sm font-bold text-center animate-in fade-in">{loginError}</div>}
            <div>
              <label className="block text-sm font-bold text-slate-300 mb-2">رقم الهاتف</label>
              <input 
                type="tel" 
                required 
                placeholder="077XXXXXXXX"
                className="w-full p-4 rounded-xl bg-slate-900/50 border border-slate-700 text-white focus:border-red-500 focus:ring-1 focus:ring-red-500 outline-none text-left placeholder:text-slate-600" 
                dir="ltr"
                value={loginPhone}
                onChange={(e) => setLoginPhone(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-300 mb-2">كلمة المرور</label>
              <input 
                type="password" 
                required 
                placeholder="••••••"
                className="w-full p-4 rounded-xl bg-slate-900/50 border border-slate-700 text-white focus:border-red-500 focus:ring-1 focus:ring-red-500 outline-none text-left placeholder:text-slate-600" 
                dir="ltr"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
              />
            </div>
            <button type="submit" className="w-full bg-red-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-red-700 transition shadow-lg shadow-red-600/20">
              تسجيل الدخول
            </button>
          </form>
        </div>

        <div className="mt-12 text-center space-y-6 relative z-10">
          <div className="text-slate-500 text-sm font-mono font-bold leading-relaxed tracking-wider">
            <p className="text-slate-400 mb-1">@2026 FOR AL-BASEEM</p>
            <p>General Trading</p>
            <p className="mt-4">BY AHMED AL NAJEM</p>
            <p>Zainab HADED</p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="https://wa.me/9647762788088" target="_blank" rel="noreferrer" className="bg-[#25D366] text-white px-6 py-2.5 rounded-full font-bold flex items-center gap-2 hover:opacity-90 transition shadow-lg shadow-green-900/20">
              <MessageCircle size={18}/> +9647762788088
            </a>
            <a href="https://instagram.com/9.cas" target="_blank" rel="noreferrer" className="bg-gradient-to-tr from-[#f09433] via-[#e6683c] to-[#bc1888] text-white px-6 py-2.5 rounded-full font-bold flex items-center gap-2 hover:opacity-90 transition shadow-lg shadow-pink-900/20">
              <Instagram size={18}/> 9.CAS
            </a>
          </div>
        </div>
      </div>
    );
  }

  if (!USER_PERMISSIONS.viewCustomersAndCities && !USER_PERMISSIONS.viewTasksSection && !USER_PERMISSIONS.viewSettings) {
    return <div className="p-10 text-center text-red-500 font-bold">عذراً، لا تملك أي صلاحيات الدخول للنظام.</div>;
  }

  const SIDEBAR_ITEMS = [
    { id: 'dashboard', label: 'لوحة التحكم', icon: <LayoutDashboard size={20}/> },
    { id: 'crm', label: 'الزبائن والمدن', icon: <Users size={20}/> },
    { id: 'tasks', label: 'مهام الموظفين', icon: <Briefcase size={20}/> },
    { id: 'whatsapp', label: 'قسم الواتساب', icon: <MessageCircle size={20}/> },
    { id: 'reminders', label: 'التذكيرات', icon: <Bell size={20}/> },
    { id: 'notes', label: 'الملاحظات', icon: <StickyNote size={20}/> },
    { id: 'settings', label: 'الإعدادات', icon: <Settings size={20}/> },
  ];

  const renderWhatsappSection = () => {
    if (!USER_PERMISSIONS.viewWhatsappSection) {
      return <div className="p-10 text-center text-red-500 font-bold">عذراً، لا تملك صلاحية الدخول لهذا القسم.</div>;
    }

    return (
      <div className="animate-in fade-in">
        <div className="flex gap-2 bg-gray-200 p-1 rounded-xl mb-6 max-w-fit overflow-x-auto">
          <button 
            className={`px-6 py-2 rounded-lg font-bold transition whitespace-nowrap ${whatsappSubSection === 'send' ? 'bg-white shadow-sm text-green-600' : 'text-gray-600 hover:bg-gray-300'}`}
            onClick={() => setWhatsappSubSection('send')}
          >
            إرسال رسالة
          </button>
          <button 
            className={`px-6 py-2 rounded-lg font-bold transition whitespace-nowrap ${whatsappSubSection === 'scheduled' ? 'bg-white shadow-sm text-green-600' : 'text-gray-600 hover:bg-gray-300'}`}
            onClick={() => setWhatsappSubSection('scheduled')}
          >
            الرسائل المجدولة
          </button>
        </div>

        {whatsappSubSection === 'send' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              {waStatus !== 'connected' && (
                <div className="bg-yellow-50 text-yellow-800 p-4 rounded-xl border border-yellow-200 flex items-center gap-3 font-bold shadow-sm">
                  <AlertTriangle size={24} className="text-yellow-600"/>
                  تنبيه: الواتساب غير متصل. يرجى ربط الحساب من قسم الإعدادات لتتمكن من الإرسال الفعلي، (حالياً في وضع المحاكاة).
                </div>
              )}

              {isSendingMessages && sendProgress && (
                <div className="bg-green-50 text-green-800 p-4 rounded-xl border border-green-200 shadow-sm">
                  <div className="flex items-center gap-3 mb-3">
                    <RefreshCw size={20} className="animate-spin text-green-600"/>
                    <span className="font-bold">جاري إرسال الرسائل...</span>
                  </div>
                  <div className="w-full bg-green-200 rounded-full h-3 overflow-hidden">
                    <div 
                      className="bg-green-600 h-full transition-all duration-300"
                      style={{ width: `${(sendProgress.current / sendProgress.total) * 100}%` }}
                    />
                  </div>
                  <p className="text-sm text-green-700 mt-2">
                    تم إرسال {sendProgress.current} من {sendProgress.total} رسالة
                  </p>
                </div>
              )}

              <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2"><MessageCircle className="text-green-500"/> محتوى الرسالة</h3>
                
                <textarea 
                  value={waMessageText}
                  onChange={(e) => setWaMessageText(e.target.value)}
                  placeholder="اكتب رسالتك هنا..." 
                  rows="5" 
                  className="w-full p-4 rounded-xl border border-gray-200 focus:border-green-500 focus:ring-1 focus:ring-green-500 outline-none resize-none mb-4 bg-gray-50"
                ></textarea>

                <div className="flex items-center gap-4 mb-6">
                  <label className="flex items-center justify-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-3 rounded-xl cursor-pointer transition flex-1 border border-dashed border-gray-300">
                    <ImageIcon size={20} className="text-green-600"/>
                    <span className="font-bold">{waMessageImage ? 'تم إرفاق صورة' : 'إرفاق صورة (اختياري)'}</span>
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => setWaMessageImage(e.target.files[0])} />
                  </label>
                  {waMessageImage && (
                    <button onClick={() => setWaMessageImage(null)} className="text-red-500 hover:bg-red-50 p-3 rounded-xl transition"><Trash2 size={20}/></button>
                  )}
                </div>

                <div className="flex gap-3 pt-4 border-t">
                  <button onClick={() => executeSendWhatsapp(false)} className="flex-1 bg-green-500 text-white py-3 rounded-xl font-bold hover:bg-green-600 transition shadow-sm flex items-center justify-center gap-2">
                    <Send size={20}/> إرسال الآن
                  </button>
                  <button onClick={() => setIsScheduleModalOpen(true)} className="flex-1 bg-blue-50 text-blue-600 border border-blue-200 py-3 rounded-xl font-bold hover:bg-blue-100 transition shadow-sm flex items-center justify-center gap-2">
                    <Clock size={20}/> جدولة الرسالة
                  </button>
                </div>
              </div>

              {sendLogs.length > 0 && (
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 animate-in slide-in-from-bottom-4">
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2"><List className="text-gray-500"/> سجل الإرسال الأخير</h3>
                  <div className="max-h-64 overflow-y-auto space-y-2 pr-2">
                    {sendLogs.map(log => (
                      <div key={log.id} className={`p-3 rounded-lg border flex items-center justify-between ${log.status === 'success' ? 'bg-green-50 border-green-100' : 'bg-red-50 border-red-100'}`}>
                        <div className="font-bold text-gray-800 flex items-center gap-2">
                          <User size={16} className="text-gray-500"/> {log.targetName}
                        </div>
                        <div className="flex items-center gap-2">
                          {log.status === 'success' ? (
                            <span className="text-green-600 flex items-center gap-1 text-sm font-bold"><CheckCircle size={16}/> تم الإرسال</span>
                          ) : (
                            <span className="text-red-600 flex items-center gap-1 text-sm font-bold"><XCircle size={16}/> فشل ({log.error})</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-max">
               <h3 className="text-lg font-bold mb-4">إرسال إلى:</h3>
               <div className="space-y-3 mb-6">
                 {[
                   { id: 'all', label: 'جميع الزبائن' },
                   { id: 'city', label: 'مدينة محددة' },
                   { id: 'specific_customers', label: 'أشخاص محددين' },
                   { id: 'employees', label: 'الموظفين' }
                 ].map(type => (
                   <label key={type.id} className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition ${waTargetType === type.id ? 'bg-green-50 border-green-500' : 'hover:bg-gray-50'}`}>
                     <input type="radio" name="targetType" value={type.id} checked={waTargetType === type.id} onChange={(e) => setWaTargetType(e.target.value)} className="w-4 h-4 text-green-600"/>
                     <span className="font-bold text-gray-700">{type.label}</span>
                   </label>
                 ))}
               </div>

               <div className="animate-in fade-in">
                 {waTargetType === 'city' && (
                   <div>
                     <label className="block text-sm font-bold text-gray-500 mb-2">اختر المدينة</label>
                     <select className="w-full p-3 rounded-xl border focus:ring-2 focus:ring-green-500 outline-none bg-gray-50" value={waSelectedCity} onChange={(e) => setWaSelectedCity(e.target.value)}>
                       <option value="">-- اختر مدينة --</option>
                       {cities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                     </select>
                   </div>
                 )}

                 {waTargetType === 'specific_customers' && (
                   <div>
                     <div className="relative mb-3">
                       <Search className="absolute right-3 top-3 text-gray-400" size={18} />
                       <input 
                         type="text" 
                         placeholder="بحث عن زبون..." 
                         className="w-full pl-3 pr-9 py-2 rounded-lg border focus:border-green-500 outline-none text-sm"
                         value={waCustomerSearch}
                         onChange={(e) => setWaCustomerSearch(e.target.value)}
                       />
                     </div>
                     <div className="max-h-60 overflow-y-auto border rounded-xl p-2 bg-gray-50 space-y-1">
                       {customers.filter(c => c.name.includes(waCustomerSearch) || c.phone.includes(waCustomerSearch)).map(c => (
                         <label key={c.id} className="flex items-center gap-2 p-2 hover:bg-gray-200 rounded-lg cursor-pointer">
                           <input type="checkbox" className="w-4 h-4 rounded text-green-600" 
                             checked={waSpecificCustomers.includes(c.id)}
                             onChange={(e) => {
                               if (e.target.checked) setWaSpecificCustomers([...waSpecificCustomers, c.id]);
                               else setWaSpecificCustomers(waSpecificCustomers.filter(id => id !== c.id));
                             }}
                           />
                           <span className="text-sm">{c.name}</span>
                         </label>
                       ))}
                     </div>
                   </div>
                 )}

                 {waTargetType === 'employees' && (
                   <div>
                     <label className="block text-sm font-bold text-gray-500 mb-2">اختر الموظفين</label>
                     <div className="max-h-60 overflow-y-auto border rounded-xl p-2 bg-gray-50 space-y-1">
                       {EMPLOYEES.map(e => (
                         <label key={e.id} className="flex items-center gap-2 p-2 hover:bg-gray-200 rounded-lg cursor-pointer">
                           <input type="checkbox" className="w-4 h-4 rounded text-green-600" 
                             checked={waSpecificEmployees.includes(e.id)}
                             onChange={(ev) => {
                               if (ev.target.checked) setWaSpecificEmployees([...waSpecificEmployees, e.id]);
                               else setWaSpecificEmployees(waSpecificEmployees.filter(id => id !== e.id));
                             }}
                           />
                           <span className="text-sm">{e.name}</span>
                         </label>
                       ))}
                     </div>
                   </div>
                 )}
               </div>
            </div>
          </div>
        )}

        {whatsappSubSection === 'scheduled' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><CalendarDays className="text-blue-500"/> الرسائل المجدولة</h3>
            <div className="grid gap-4">
              {scheduledMessages.map(msg => (
                <div key={msg.id} className="border border-gray-200 rounded-xl p-5 hover:shadow-md transition bg-gray-50 flex flex-col md:flex-row justify-between md:items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1"><Clock size={12}/> {msg.scheduleDate.replace('T', ' - ')}</span>
                      <span className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-xs font-bold">المستهدف: {msg.targetLabel}</span>
                      {msg.hasImage && <span className="text-green-600"><ImageIcon size={16}/></span>}
                    </div>
                    <p className="text-gray-800 font-medium line-clamp-2">{msg.text || '[صورة فقط]'}</p>
                  </div>
                  <button onClick={() => handleCancelScheduledMsg(msg.id)} className="bg-red-50 text-red-600 px-4 py-2 rounded-lg font-bold hover:bg-red-100 transition whitespace-nowrap flex items-center justify-center gap-2">
                    <XCircle size={18}/> إلغاء الجدولة
                  </button>
                </div>
              ))}
              {scheduledMessages.length === 0 && (
                <div className="text-center py-12 text-gray-400 font-bold">
                  <CalendarDays size={48} className="mx-auto mb-3 opacity-50"/>
                  لا توجد رسائل مجدولة حالياً.
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderSettingsSection = () => {
    if (!USER_PERMISSIONS.viewSettings) {
      return <div className="p-10 text-center text-red-500 font-bold">عذراً، لا تملك صلاحية الدخول للاعدادات.</div>;
    }

    return (
      <div className="animate-in fade-in space-y-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2"><Settings size={28} className="text-slate-600"/> إعدادات النظام</h2>
        
        <div className="flex gap-2 bg-gray-200 p-1 rounded-xl max-w-fit overflow-x-auto">
          {[
            { id: 'users', label: 'المستخدمين', icon: <Users size={16}/> },
            { id: 'backup', label: 'النسخة الاحتياطية', icon: <Database size={16}/> },
            { id: 'whatsapp', label: 'ربط واتساب', icon: <Smartphone size={16}/> },
            { id: 'import', label: 'استيراد الزبائن', icon: <FileSpreadsheet size={16}/> }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setSettingsTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-2 rounded-lg font-bold transition whitespace-nowrap ${settingsTab === tab.id ? 'bg-white shadow-sm text-slate-800' : 'text-gray-600 hover:bg-gray-300'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>

        {settingsTab === 'users' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-in fade-in">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold flex items-center gap-2"><Users className="text-indigo-500"/> إدارة المستخدمين</h3>
              {USER_PERMISSIONS.addUser && (
                <button onClick={() => { setEditingUser(null); setIsUserModalOpen(true); }} className="bg-indigo-600 text-white px-5 py-2 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition">
                  <Plus size={18}/> إضافة مستخدم
                </button>
              )}
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {employeesList.map(emp => (
                <div key={emp.id} className="border border-gray-200 rounded-xl p-5 hover:shadow-md transition bg-gray-50 flex flex-col">
                  <div className="flex items-center gap-3 mb-3 border-b pb-3">
                    <div className="bg-indigo-100 p-3 rounded-full text-indigo-600"><User size={24}/></div>
                    <div>
                      <h4 className="font-bold text-lg text-gray-800">{emp.name}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full font-bold ${emp.role === 'manager' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                        {emp.role === 'manager' ? 'مشرف' : 'موظف'}
                      </span>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600 space-y-2 mb-4 flex-1">
                    <div className="flex items-center gap-2"><Phone size={14}/> {emp.phone}</div>
                    <div className="flex items-center gap-2"><Lock size={14}/> كلمة المرور: ***</div>
                    <div className="flex items-center gap-2"><Shield size={14}/> الصلاحيات الممنوحة: {emp.permissions.length}</div>
                  </div>
                  <div className="flex gap-2 pt-3 border-t mt-auto">
                    {USER_PERMISSIONS.editUser && (
                      <button onClick={() => { setEditingUser(emp); setIsUserModalOpen(true); }} className="flex-1 bg-blue-50 text-blue-600 py-2 rounded-lg font-bold hover:bg-blue-100 transition flex items-center justify-center gap-1">
                        <Edit size={16}/> تعديل
                      </button>
                    )}
                    {USER_PERMISSIONS.deleteUser && (
                      <button onClick={() => handleDeleteUser(emp.id)} className="bg-red-50 text-red-600 p-2 rounded-lg hover:bg-red-100 transition">
                        <Trash2 size={20}/>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {settingsTab === 'backup' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-in fade-in max-w-2xl">
            <h3 className="text-xl font-bold flex items-center gap-2 mb-6"><Database className="text-blue-500"/> النسخة الاحتياطية</h3>
            
            <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl mb-6 flex items-center justify-between">
              <div>
                <p className="text-blue-800 font-bold">آخر نسخة احتياطية تم أخذها:</p>
                <p className="text-blue-600 text-sm mt-1">{lastBackup.time} (بواسطة: {lastBackup.user})</p>
              </div>
              <Database size={32} className="text-blue-300"/>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {USER_PERMISSIONS.makeBackup && (
                <button onClick={handleMakeBackup} className="border-2 border-dashed border-blue-300 bg-white p-8 rounded-xl flex flex-col items-center justify-center text-blue-600 hover:bg-blue-50 transition group cursor-pointer">
                  <Download size={40} className="mb-3 group-hover:scale-110 transition-transform"/>
                  <span className="font-bold text-lg">تنزيل نسخة احتياطية</span>
                  <span className="text-xs text-blue-400 mt-2">حفظ قاعدة البيانات كملف محلي</span>
                </button>
              )}
              
              {USER_PERMISSIONS.restoreBackup && (
                <label className="border-2 border-dashed border-green-300 bg-white p-8 rounded-xl flex flex-col items-center justify-center text-green-600 hover:bg-green-50 transition group cursor-pointer">
                  <Upload size={40} className="mb-3 group-hover:scale-110 transition-transform"/>
                  <span className="font-bold text-lg">رفع نسخة احتياطية</span>
                  <span className="text-xs text-green-400 mt-2">استعادة البيانات من ملف سابق</span>
                  <input type="file" className="hidden" accept=".json,.db" onChange={handleRestoreBackup} />
                </label>
              )}
            </div>
          </div>
        )}

        {settingsTab === 'whatsapp' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-in fade-in max-w-2xl">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h3 className="text-xl font-bold flex items-center gap-2"><Smartphone className="text-green-500"/> إعدادات ربط الواتساب</h3>
                <p className="text-gray-500 text-sm mt-1">قم بربط حساب الواتساب الخاص بالشركة لإرسال الرسائل تلقائياً.</p>
              </div>
              <div className="flex items-center gap-2">
                <span className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${waStatus === 'connected' ? 'bg-green-50 text-green-600 border border-green-200' : waStatus === 'connecting' ? 'bg-yellow-50 text-yellow-600 border border-yellow-200' : 'bg-gray-50 text-gray-600 border border-gray-200'}`}>
                  {waStatus === 'connected' ? <><Wifi size={12}/> متصل</> : waStatus === 'connecting' ? <><RefreshCw size={12} className="animate-spin"/> جاري الربط</> : <><WifiOff size={12}/> غير متصل</>}
                </span>
                {!USER_PERMISSIONS.manageWhatsappConnection && (
                  <span className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-xs font-bold border border-red-100">صلاحية إدارة فقط</span>
                )}
              </div>
            </div>

            {USER_PERMISSIONS.manageWhatsappConnection && (
              <div className="mb-6 p-4 border rounded-xl bg-gray-50">
                <label className="block text-sm font-bold text-gray-700 mb-2">المدة بين رسالة وأخرى عند الإرسال الجماعي (بالثواني)</label>
                <input 
                  type="number" 
                  min="1" 
                  value={waMessageDelay} 
                  onChange={(e) => setWaMessageDelay(parseInt(e.target.value) || 5)} 
                  className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-green-500 outline-none" 
                />
              </div>
            )}

            <div className="bg-gray-50 border rounded-xl p-6 flex flex-col items-center text-center">
              {waStatus === 'connected' ? (
                <div className="animate-in zoom-in flex flex-col items-center">
                  <div className="w-20 h-20 bg-green-100 text-green-500 rounded-full flex items-center justify-center mb-4">
                    <CheckCircle size={40}/>
                  </div>
                  <h4 className="text-2xl font-bold text-gray-800 mb-1">الحساب متصل بنجاح</h4>
                  <p className="text-gray-600 text-lg mb-6" dir="ltr">{waPhone}</p>
                  {USER_PERMISSIONS.disconnectWhatsapp && (
                    <button onClick={handleDisconnectWhatsapp} className="bg-white border border-red-500 text-red-600 px-6 py-2 rounded-lg font-bold hover:bg-red-50 transition">
                      إلغاء الربط وربط جهاز آخر
                    </button>
                  )}
                </div>
              ) : waStatus === 'connecting' ? (
                <div className="animate-in fade-in flex flex-col items-center w-full max-w-sm">
                  {waQrCode && waQrCode.startsWith('data:image') ? (
                    <div className="mb-4 bg-white p-4 rounded-xl border-2 border-green-400 shadow-lg relative">
                      <img 
                        src={waQrCode} 
                        alt="WhatsApp QR Code" 
                        className="w-64 h-64 object-contain"
                      />
                      <div className="absolute -top-2 -right-2 bg-green-500 text-white rounded-full p-1">
                        <QrCode size={16}/>
                      </div>
                    </div>
                  ) : (
                    <div className="mb-4 bg-white p-4 rounded-xl border-2 border-dashed border-gray-300 relative w-64 h-64 flex flex-col items-center justify-center">
                      <RefreshCw size={48} className="text-gray-400 animate-spin"/>
                      <p className="text-gray-500 mt-2 text-sm">جاري توليد الكود...</p>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-gray-600 font-bold mb-4">
                    <RefreshCw size={16} className="animate-spin text-green-600"/>
                    يتم تحديث الرمز خلال: <span className="text-green-600 text-lg">{waQrTimer}</span> ثانية
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-4 w-full">
                    <p className="text-blue-800 font-bold text-sm mb-2">طريقة الربط:</p>
                    <ol className="text-blue-700 text-xs text-right space-y-1">
                      <li>1. افتح تطبيق الواتساب في هاتفك</li>
                      <li>2. اضغط على القائمة (النقاط الثلاث)</li>
                      <li>3. اختر "الأجهزة المرتبطة"</li>
                      <li>4. اضغط "ربط جهاز"</li>
                      <li>5. امسح رمز QR أعلاه</li>
                    </ol>
                  </div>
                  
                  <button onClick={handleSimulateScan} className="text-sm text-blue-500 underline hover:text-blue-700">
                    (للاختبار: اضغط هنا لمحاكاة نجاح مسح الكود)
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 bg-gray-200 text-gray-400 rounded-full flex items-center justify-center mb-4">
                    <Smartphone size={40}/>
                  </div>
                  <h4 className="text-xl font-bold text-gray-800 mb-2">الواتساب غير متصل</h4>
                  <p className="text-gray-500 mb-6 max-w-md">النظام غير قادر على إرسال رسائل الواتساب التلقائية حالياً. يرجى مسح رمز الـ QR لربط حسابك.</p>
                  {USER_PERMISSIONS.connectWhatsapp && (
                    <button 
                      onClick={handleConnectWhatsapp} 
                      disabled={waLoading}
                      className="bg-green-500 text-white px-8 py-3 rounded-xl font-bold hover:bg-green-600 transition shadow-sm flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {waLoading ? (
                        <>
                          <RefreshCw size={20} className="animate-spin"/>
                          جاري التوليد...
                        </>
                      ) : (
                        <>
                          <QrCode size={20}/> توليد رمز الربط (QR)
                        </>
                      )}
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {settingsTab === 'import' && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 animate-in fade-in max-w-2xl">
            <h3 className="text-xl font-bold flex items-center gap-2 mb-6"><FileSpreadsheet className="text-emerald-500"/> استيراد الزبائن</h3>
            
            {USER_PERMISSIONS.importCustomers ? (
              <form onSubmit={handleImportCustomers} className="space-y-6">
                <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl text-emerald-800 text-sm">
                  <strong>ملاحظة:</strong> يجب أن يحتوي ملف الإكسل (Excel) على 3 أعمدة رئيسية: <strong>الاسم، الرقم، العنوان</strong>.
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">اختر المدينة التي سيتم استيراد الزبائن إليها</label>
                  <select 
                    required 
                    className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-emerald-500 outline-none bg-gray-50"
                    value={importCityId}
                    onChange={(e) => setImportCityId(e.target.value)}
                  >
                    <option value="">-- اختر مدينة --</option>
                    {cities.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">ملف الإكسل (.xlsx, .csv)</label>
                  <input 
                    required 
                    id="importFile"
                    type="file" 
                    accept=".xlsx, .xls, .csv" 
                    className="w-full p-3 rounded-lg border outline-none bg-gray-50" 
                  />
                </div>

                <button type="submit" className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition shadow-sm flex items-center justify-center gap-2">
                  <Upload size={20}/> بدء الاستيراد
                </button>
              </form>
            ) : (
              <div className="text-red-500 font-bold text-center py-6">عذراً، لا تملك صلاحية استيراد الزبائن.</div>
            )}
          </div>
        )}
      </div>
    );
  };

  const renderRemindersSection = () => {
    if (!USER_PERMISSIONS.viewRemindersSection) {
      return <div className="p-10 text-center text-red-500 font-bold">عذراً، لا تملك صلاحية الدخول لهذا القسم.</div>;
    }

    const todayStr = new Date().toISOString().split('T')[0];

    const visibleReminders = USER_PERMISSIONS.viewAllReminders 
      ? reminders 
      : reminders.filter(r => r.employeeIds.includes(CURRENT_USER?.id));

    const processedReminders = visibleReminders.map(r => {
      const isCompletedByMe = r.completions.some(c => c.employeeId === CURRENT_USER?.id);
      const isCompletedByAnyone = r.completions.length > 0;
      
      const isFullyCompletedForMe = r.completionType === 'single' ? isCompletedByAnyone : isCompletedByMe;

      let status = 'active';
      if (isFullyCompletedForMe) status = 'completed';
      else if (r.date < todayStr) status = 'pending';

      return { ...r, status, isFullyCompletedForMe };
    });

    const filteredReminders = processedReminders.filter(r => {
      if (remindersTab === 'today') return r.date === todayStr;
      if (remindersTab === 'active') return r.status === 'active';
      if (remindersTab === 'completed') return r.status === 'completed';
      if (remindersTab === 'pending') return r.status === 'pending';
      return true;
    });

    return (
      <div className="animate-in fade-in">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2"><Bell className="text-amber-500"/> قسم التذكيرات</h2>
          {USER_PERMISSIONS.addReminder && (
            <button onClick={() => setIsAddReminderOpen(true)} className="bg-amber-500 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-amber-600 transition shadow-sm">
              <Plus size={20} /> إضافة تذكير
            </button>
          )}
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-2 mb-6 flex flex-wrap gap-2">
          {[
            { id: 'today', label: 'تذكيرات اليوم', icon: <Calendar size={16}/> },
            { id: 'active', label: 'النشطة', icon: <Clock size={16}/> },
            { id: 'completed', label: 'المنجزة', icon: <CheckCircle size={16}/> },
            { id: 'pending', label: 'المعلقة', icon: <AlertTriangle size={16}/> },
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setRemindersTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold transition ${remindersTab === tab.id ? 'bg-amber-50 text-amber-700' : 'text-gray-600 hover:bg-gray-100'}`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredReminders.map(reminder => (
            <div key={reminder.id} className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition flex flex-col">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                  <Bell size={18} className={reminder.status === 'pending' ? 'text-red-500' : 'text-amber-500'}/> {reminder.title}
                </h3>
                <span className={`text-xs px-2 py-1 rounded-full font-bold ${
                  reminder.status === 'active' ? 'bg-blue-100 text-blue-700' :
                  reminder.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}>
                  {reminder.status === 'active' ? 'نشط' : reminder.status === 'completed' ? 'منجز' : 'معلق'}
                </span>
              </div>
              
              <p className="text-gray-600 text-sm mb-4 whitespace-pre-wrap flex-1">{reminder.details}</p>
              
              <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600 mb-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1"><CalendarDays size={14}/> {reminder.date}</span>
                  <span className="flex items-center gap-1"><Clock size={14}/> {reminder.isFullDay ? 'طوال اليوم' : `${reminder.startTime} - ${reminder.endTime}`}</span>
                </div>
                <div className="border-t pt-2 mt-2">
                  <strong>المشمولين:</strong> {reminder.employeeIds.map(id => EMPLOYEES.find(e=>e.id===id)?.name).join('، ')}
                </div>
                <div className="text-xs text-amber-600 font-bold">
                  ({reminder.completionType === 'single' ? 'ينجز من قبل موظف واحد وينتهي' : 'يجب أن ينجز من قبل كل موظف مشمول'})
                </div>
              </div>

              {reminder.completions.length > 0 && (
                <div className="bg-green-50 border border-green-100 p-3 rounded-lg text-sm mb-4">
                  <strong className="text-green-800 mb-1 block">سجل الإنجاز:</strong>
                  {reminder.completions.map((comp, i) => (
                    <div key={i} className="mb-1 border-b border-green-200 pb-1 last:border-0 last:pb-0">
                      <span className="font-bold text-green-700">{EMPLOYEES.find(e=>e.id === comp.employeeId)?.name}:</span> {comp.details} <span className="text-xs text-green-600">({comp.date})</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex gap-2 pt-3 border-t mt-auto">
                {['active', 'pending'].includes(reminder.status) && reminder.employeeIds.includes(CURRENT_USER?.id) && (
                  <button onClick={() => setReminderCompletionModal({ reminder })} className="flex-1 bg-green-50 text-green-700 py-2 rounded-lg font-bold hover:bg-green-100 transition flex items-center justify-center gap-1">
                    <CheckCircle size={16}/> إنجاز التذكير
                  </button>
                )}
                {USER_PERMISSIONS.deleteReminder && (
                  <button onClick={() => handleDeleteReminder(reminder.id)} className="bg-red-50 text-red-600 p-2 rounded-lg hover:bg-red-100 transition">
                    <Trash2 size={20}/>
                  </button>
                )}
              </div>
            </div>
          ))}
          {filteredReminders.length === 0 && (
            <div className="col-span-full text-center py-12 bg-white rounded-xl border border-gray-100 text-gray-500">
              لا توجد تذكيرات مطابقة في هذا القسم.
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderTaskDashboard = (employee) => (
    <div className="animate-in fade-in slide-in-from-right-4">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">مهام: {employee.name}</h2>
          <p className="text-gray-500 mt-1">إدارة المهام وتتبع الإنجاز</p>
        </div>
        {USER_PERMISSIONS.addTask && (
          <button onClick={() => setIsAddTaskOpen(true)} className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 hover:bg-indigo-700 transition shadow-sm">
            <Plus size={20} /> إضافة مهمة
          </button>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-2 mb-6 flex flex-wrap gap-2">
        {[
          { id: 'active', label: 'النشطة', icon: <Clock size={16}/> },
          { id: 'completed', label: 'المنجزة', icon: <CheckCircle size={16}/> },
          { id: 'delayed', label: 'المؤجلة', icon: <CalendarDays size={16}/> },
          { id: 'pending', label: 'المعلقة', icon: <AlertTriangle size={16}/> },
          { id: 'canceled', label: 'الملغية', icon: <XCircle size={16}/> },
          { id: 'all', label: 'الكل', icon: <List size={16}/> }
        ].map(tab => (
          <button 
            key={tab.id}
            onClick={() => setTaskActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold transition ${taskActiveTab === tab.id ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {(taskActiveTab === 'active' || taskActiveTab === 'completed') && (
        <div className="mb-6 bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4 w-full md:w-max">
          <label className="font-bold text-gray-700">
            {taskActiveTab === 'active' ? 'تاريخ عرض المهام النشطة:' : 'تاريخ عرض المهام المنجزة:'}
          </label>
          <input 
            type="date" 
            value={taskDateFilter}
            onChange={(e) => setTaskDateFilter(e.target.value)}
            className="p-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredDashboardTasks.map((task, idx) => (
          <div key={task.id || idx} className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-bold text-gray-800">{task.title}</h3>
              <span className={`text-xs px-2 py-1 rounded-full font-bold ${
                task.status === 'active' ? 'bg-blue-100 text-blue-700' :
                task.status === 'completed' ? 'bg-green-100 text-green-700' :
                task.status === 'delayed' ? 'bg-yellow-100 text-yellow-700' :
                task.status === 'pending' ? 'bg-orange-100 text-orange-700' :
                'bg-red-100 text-red-700'
              }`}>
                {task.status === 'active' ? 'نشطة' : task.status === 'completed' ? 'منجزة' : task.status === 'delayed' ? 'مؤجلة' : task.status === 'pending' ? 'معلقة' : 'ملغية'}
              </span>
            </div>
            <p className="text-gray-600 text-sm mb-4 whitespace-pre-wrap">{task.details}</p>
            
            <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600 mb-4 space-y-1">
              <div className="flex items-center gap-2"><CalendarDays size={14}/> <strong>التاريخ:</strong> {task.date || 'متكررة (تحتاج إجراء لتسجيلها)'}</div>
              <div className="flex items-center gap-2"><Clock size={14}/> <strong>الوقت:</strong> {task.isFullDay ? 'يوم كامل' : `من ${task.startTime} إلى ${task.endTime}`}</div>
              {task.status === 'delayed' && <div className="text-yellow-700 mt-2"><strong>سبب التأجيل:</strong> {task.delayReason}</div>}
              {task.status === 'canceled' && <div className="text-red-700 mt-2"><strong>سبب الإلغاء:</strong> {task.cancelReason} <br/><span className="text-xs">(بواسطة: {task.canceledBy})</span></div>}
              {task.status === 'completed' && <div className="text-green-700 mt-2"><strong>تفاصيل الإنجاز:</strong> {task.completionDetails}</div>}
            </div>

            <div className="flex flex-wrap gap-2 pt-3 border-t">
              {task.status === 'active' && taskActiveTab !== 'all' && (
                <>
                  <button onClick={() => setTaskActionModal({type: 'complete', task})} className="flex-1 bg-green-50 text-green-700 py-2 rounded-lg font-bold hover:bg-green-100 transition flex items-center justify-center gap-1"><CheckCircle size={16}/> إنجاز</button>
                  {USER_PERMISSIONS.delayTask && <button onClick={() => setTaskActionModal({type: 'delay', task})} className="flex-1 bg-yellow-50 text-yellow-700 py-2 rounded-lg font-bold hover:bg-yellow-100 transition flex items-center justify-center gap-1"><Clock size={16}/> تأجيل</button>}
                  {USER_PERMISSIONS.cancelTask && <button onClick={() => setTaskActionModal({type: 'cancel', task})} className="flex-1 bg-red-50 text-red-700 py-2 rounded-lg font-bold hover:bg-red-100 transition flex items-center justify-center gap-1"><XCircle size={16}/> إلغاء</button>}
                </>
              )}
              {task.status === 'delayed' && taskActiveTab !== 'all' && (
                 <>
                  <button onClick={() => setTaskActionModal({type: 'complete', task})} className="flex-1 bg-green-50 text-green-700 py-2 rounded-lg font-bold hover:bg-green-100 transition flex items-center justify-center gap-1"><CheckCircle size={16}/> إنجاز</button>
                  <button onClick={() => setTaskActionModal({type: 'cancel', task})} className="flex-1 bg-red-50 text-red-700 py-2 rounded-lg font-bold hover:bg-red-100 transition flex items-center justify-center gap-1"><XCircle size={16}/> إلغاء</button>
                 </>
              )}
              {task.status === 'pending' && taskActiveTab !== 'all' && (
                 <>
                  <button onClick={() => setTaskActionModal({type: 'reschedule', task})} className="flex-1 bg-blue-50 text-blue-700 py-2 rounded-lg font-bold hover:bg-blue-100 transition flex items-center justify-center gap-1"><CalendarDays size={16}/> إعادة رفع</button>
                  <button onClick={() => setTaskActionModal({type: 'cancel', task})} className="flex-1 bg-red-50 text-red-700 py-2 rounded-lg font-bold hover:bg-red-100 transition flex items-center justify-center gap-1"><XCircle size={16}/> إلغاء</button>
                 </>
              )}
            </div>
          </div>
        ))}
        {filteredDashboardTasks.length === 0 && (
          <div className="col-span-full text-center py-12 bg-white rounded-xl border border-gray-100 text-gray-500">
            لا توجد مهام مطابقة في هذا القسم.
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-50 text-gray-800 font-sans overflow-hidden" dir="rtl">
      
      {isSidebarOpen && <div className="fixed inset-0 bg-slate-900/50 z-40 md:hidden" onClick={() => setIsSidebarOpen(false)} />}

      <aside className={`fixed md:static inset-y-0 right-0 z-50 w-64 bg-slate-900 text-slate-300 transition-transform transform ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0'} flex flex-col shadow-xl md:shadow-none`}>
        <div className="p-5 bg-slate-950 flex flex-col gap-2">
          <h1 className="text-xl font-bold text-white tracking-wide">AL-BASEEM</h1>
          <div className="flex items-center justify-between bg-slate-800 p-2 rounded-lg">
            <div className="flex items-center gap-2 text-sm text-slate-300">
              <User size={16} className="text-indigo-400"/>
              <span className="truncate">{CURRENT_USER.name}</span>
            </div>
            <button onClick={() => setCurrentUser(null)} className="text-red-400 hover:text-red-300 transition" title="تسجيل الخروج">
              <LogOut size={16}/>
            </button>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1 scrollbar-hide">
          {SIDEBAR_ITEMS.map(item => {
            if (item.id === 'crm' && !USER_PERMISSIONS.viewCustomersAndCities) return null;
            if (item.id === 'tasks' && !USER_PERMISSIONS.viewTasksSection) return null;
            if (item.id === 'whatsapp' && !USER_PERMISSIONS.viewWhatsappSection) return null;
            if (item.id === 'reminders' && !USER_PERMISSIONS.viewRemindersSection) return null;
            if (item.id === 'notes' && !USER_PERMISSIONS.viewNotesSection) return null;

            const isActive = appSection === item.id;
            return (
              <button 
                key={item.id}
                onClick={() => { setAppSection(item.id); setIsSidebarOpen(false); }}
                className={`flex items-center gap-3 w-full p-3 rounded-xl font-bold transition-colors ${isActive ? 'bg-indigo-600 text-white' : 'hover:bg-slate-800 hover:text-white text-slate-400'}`}
              >
                {item.icon}
                {item.label}
              </button>
            )
          })}
        </nav>
      </aside>

      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white shadow-sm p-4 flex items-center justify-between md:hidden z-10">
          <button onClick={() => setIsSidebarOpen(true)} className="text-slate-800 p-1"><Menu size={24}/></button>
          <h1 className="font-bold text-lg">AL-BASEEM MGT</h1>
          <div className="w-8"></div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-6 container mx-auto max-w-6xl">

          {['dashboard'].includes(appSection) && (
            <div className="flex flex-col items-center justify-center h-full text-gray-400 animate-in fade-in py-20">
              <div className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center gap-4 text-center">
                <Settings size={48} className="text-indigo-200" />
                <h2 className="text-2xl font-bold text-gray-800">هذا القسم قيد التطوير</h2>
                <p>قسم <span className="text-indigo-600 font-bold">{SIDEBAR_ITEMS.find(i => i.id === appSection)?.label}</span> سيتم إضافته قريباً...</p>
              </div>
            </div>
          )}
          
          {appSection === 'settings' && renderSettingsSection()}

          {appSection === 'whatsapp' && renderWhatsappSection()}

          {appSection === 'reminders' && renderRemindersSection()}

          {appSection === 'notes' && (
            <div className="animate-in fade-in flex flex-col h-[calc(100vh-100px)]">
               <div className="mb-6 shrink-0">
                 <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2 mb-4"><StickyNote className="text-purple-500"/> قسم الملاحظات</h2>
                 <div className="relative">
                   <Search className="absolute right-3 top-3.5 text-gray-400" size={20} />
                   <input
                     type="text"
                     placeholder="البحث في جميع الملاحظات عن كلمة محددة..."
                     className="w-full pl-4 pr-10 py-3 rounded-xl border border-gray-300 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none shadow-sm"
                     value={noteSearch}
                     onChange={(e) => setNoteSearch(e.target.value)}
                   />
                 </div>
               </div>

               <div className="flex-1 overflow-y-auto pr-2 space-y-4 mb-4 pb-4">
                 {filteredNotes.map(note => (
                   <div key={note.id} className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 flex flex-col gap-3 relative group transition hover:border-purple-200">
                     <p className="text-gray-800 whitespace-pre-wrap leading-relaxed">{note.content}</p>
                     <div className="flex items-center justify-between text-xs text-gray-500 pt-3 border-t">
                       <span className="flex items-center gap-1 font-bold text-gray-600"><User size={14}/> {note.author}</span>
                       <span className="flex items-center gap-1"><Calendar size={14}/> {note.date}</span>
                     </div>
                     {USER_PERMISSIONS.deleteNote && (
                       <button onClick={() => handleDeleteNote(note.id)} className="absolute top-3 left-3 text-red-400 hover:text-red-600 hover:bg-red-50 p-2 rounded-lg opacity-0 group-hover:opacity-100 transition" title="حذف الملاحظة">
                         <Trash2 size={18}/>
                       </button>
                     )}
                   </div>
                 ))}
                 {filteredNotes.length === 0 && (
                   <div className="text-center py-12 text-gray-400 font-bold bg-white rounded-xl border border-gray-100">
                     <StickyNote size={48} className="mx-auto mb-3 opacity-30 text-purple-500"/>
                     لا توجد ملاحظات مطابقة للبحث.
                   </div>
                 )}
               </div>

               {USER_PERMISSIONS.addNote && (
                 <form onSubmit={handleAddNote} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-200 flex gap-3 mt-auto shrink-0">
                   <textarea
                     value={newNoteText}
                     onChange={(e) => setNewNoteText(e.target.value)}
                     placeholder="اكتب ملاحظتك هنا..."
                     className="flex-1 p-3 rounded-xl border border-gray-200 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none resize-none bg-gray-50 max-h-32 min-h-[50px]"
                     rows="2"
                   ></textarea>
                   <button type="submit" className="bg-purple-600 text-white px-6 rounded-xl font-bold hover:bg-purple-700 transition shadow-sm flex items-center justify-center gap-2 h-auto self-end py-3">
                     <Send size={20}/> إرسال
                   </button>
                 </form>
               )}
            </div>
          )}

          {appSection === 'crm' && (
            <>
              {selectedCustomer ? (
                <div className="animate-in fade-in slide-in-from-right-4">
                  <button 
                    onClick={() => setSelectedCustomer(null)}
                    className="flex items-center gap-2 text-blue-600 font-medium mb-6 hover:text-blue-800 transition"
                  >
                    <ChevronRight size={20} /> العودة للقائمة
                  </button>

                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-6">
                    <h2 className="text-2xl font-bold mb-2">{selectedCustomer.name}</h2>
                    <p className="text-gray-500 mb-4">{selectedCustomer.address} - {selectedCustomer.phone}</p>
                    
                    <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-xl mb-6">
                      <h4 className="text-yellow-800 font-bold mb-1 flex items-center gap-2">
                        <AlertTriangle size={18} /> ملاحظة الإدارة:
                      </h4>
                      {USER_PERMISSIONS.editAdminNote ? (
                        <textarea 
                          className="w-full bg-transparent border-none outline-none resize-none text-yellow-900"
                          value={adminNote}
                          onChange={(e) => setAdminNote(e.target.value)}
                        />
                      ) : (
                        <p className="text-yellow-900">{adminNote}</p>
                      )}
                    </div>

                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-xl font-bold flex items-center gap-2">
                        <FileText className="text-blue-600"/> سجل التقارير
                      </h3>
                      {USER_PERMISSIONS.addReport && (
                        <button onClick={() => setIsAddReportOpen(true)} className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 transition">
                          <Plus size={18}/> إضافة تقرير
                        </button>
                      )}
                    </div>

                    <input 
                      type="text" 
                      placeholder="البحث في التقارير (العنوان أو المحتوى)..." 
                      className="w-full p-3 rounded-lg border border-gray-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none mb-4"
                      value={reportSearch}
                      onChange={(e) => setReportSearch(e.target.value)}
                    />

                    <div className="space-y-4">
                      {selectedCustomer.reports
                        .filter(r => r.title.includes(reportSearch) || r.content.includes(reportSearch))
                        .map(report => (
                        <details key={report.id} className="group bg-gray-50 border border-gray-200 rounded-xl overflow-hidden">
                          <summary className="cursor-pointer p-4 font-bold flex justify-between items-center hover:bg-gray-100 transition list-none">
                            <div className="flex items-center gap-3">
                              <span className="text-blue-600 group-open:rotate-90 transition-transform">▶</span>
                              {report.title}
                            </div>
                            <div className="flex items-center gap-4 text-sm font-normal text-gray-500">
                              <span className="flex items-center gap-1"><User size={14}/> {report.author}</span>
                              <span className="flex items-center gap-1"><Calendar size={14}/> {report.date}</span>
                            </div>
                          </summary>
                          <div className="p-4 bg-white border-t border-gray-200 text-gray-700 whitespace-pre-wrap relative">
                            {report.content}
                            {USER_PERMISSIONS.deleteReport && (
                              <button onClick={() => handleDeleteReport(report.id)} className="absolute bottom-4 left-4 text-red-500 hover:bg-red-50 p-2 rounded-lg">
                                <Trash2 size={16} />
                              </button>
                            )}
                          </div>
                        </details>
                      ))}
                      {selectedCustomer.reports.length === 0 && (
                        <p className="text-center text-gray-500 py-8">لا توجد تقارير لهذا الزبون.</p>
                      )}
                    </div>
                  </div>
                </div>
              ) : selectedCity ? (
                
                <div className="animate-in fade-in slide-in-from-right-4">
                   <button 
                    onClick={() => setSelectedCity(null)}
                    className="flex items-center gap-2 text-blue-600 font-medium mb-6 hover:text-blue-800 transition"
                  >
                    <ChevronRight size={20} /> العودة للمدن
                  </button>

                  <div className="mb-6 flex justify-between items-center">
                    <div>
                      <h2 className="text-2xl font-bold flex items-center gap-2">
                        <MapPin className="text-blue-600" /> مدينة: {selectedCity.name}
                      </h2>
                      <p className="text-gray-500 mt-1">ترتيب الزبائن الخاص بك (حسب الأحدث)</p>
                    </div>
                  </div>

                  <div className="relative mb-6">
                    <Search className="absolute right-3 top-3.5 text-gray-400" size={20} />
                    <input 
                      type="text" 
                      placeholder="البحث عن زبون داخل هذه المدينة..." 
                      className="w-full pl-4 pr-10 py-3 rounded-xl border border-gray-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none shadow-sm"
                      value={cityCustomerSearch}
                      onChange={(e) => setCityCustomerSearch(e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {cityFilteredCustomers.map(customer => (
                      <CustomerCard key={customer.id} customer={customer} />
                    ))}
                    {cityFilteredCustomers.length === 0 && (
                      <div className="col-span-full text-center py-10 text-gray-500">
                        لا يوجد زبائن مطابقين للبحث في هذه المدينة.
                      </div>
                    )}
                  </div>
                </div>

              ) : (
                
                <>
                  <div className="flex gap-2 bg-gray-200 p-1 rounded-xl mb-6 max-w-sm mx-auto">
                    <button 
                      className={`flex-1 py-2 rounded-lg font-bold transition ${activeTab === 'customers' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-600 hover:bg-gray-300'}`}
                      onClick={() => setActiveTab('customers')}
                    >
                      الزبائن
                    </button>
                    <button 
                      className={`flex-1 py-2 rounded-lg font-bold transition ${activeTab === 'cities' ? 'bg-white shadow-sm text-blue-600' : 'text-gray-600 hover:bg-gray-300'}`}
                      onClick={() => setActiveTab('cities')}
                    >
                      المدن
                    </button>
                  </div>

                  {activeTab === 'customers' && (
                    <div className="animate-in fade-in">
                      <div className="flex flex-col md:flex-row gap-4 mb-6">
                        <div className="relative flex-1">
                          <Search className="absolute right-3 top-3.5 text-gray-400" size={20} />
                          <input 
                            type="text" 
                            placeholder="البحث بالاسم، العنوان، أو الرقم..." 
                            className="w-full pl-4 pr-10 py-3 rounded-xl border border-gray-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none shadow-sm"
                            value={customerSearch}
                            onChange={(e) => setCustomerSearch(e.target.value)}
                          />
                        </div>
                        {USER_PERMISSIONS.addCustomer && (
                          <button 
                            onClick={() => setIsAddCustomerOpen(true)}
                            className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition shadow-sm whitespace-nowrap"
                          >
                            <Plus size={20} /> إضافة زبون
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {filteredCustomers.map(customer => (
                          <CustomerCard key={customer.id} customer={customer} />
                        ))}
                        {filteredCustomers.length === 0 && (
                          <div className="col-span-full text-center py-10 text-gray-500">
                            لا يوجد زبائن.
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {activeTab === 'cities' && (
                    <div className="animate-in fade-in">
                       <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold">قائمة المدن المتاحة</h2>
                        {USER_PERMISSIONS.addCity && (
                          <button 
                            onClick={() => setIsAddCityOpen(true)}
                            className="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-blue-700 transition shadow-sm"
                          >
                            <Plus size={20} /> إضافة مدينة
                          </button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {cities.map(city => {
                          const cityCustomersCount = customers.filter(c => c.cityIds.includes(city.id)).length;
                          return (
                            <div key={city.id} className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center group">
                              <div 
                                className="cursor-pointer flex-1"
                                onClick={() => setSelectedCity(city)}
                              >
                                <h3 className="text-lg font-bold text-gray-800">{city.name}</h3>
                                <p className="text-sm text-gray-500 mt-1">الزبائن المرتبطين: {cityCustomersCount}</p>
                              </div>
                              <div className="flex items-center gap-2">
                                 <button onClick={() => setSelectedCity(city)} className="text-blue-500 hover:bg-blue-50 p-2 rounded-lg opacity-0 group-hover:opacity-100 transition">
                                   عرض
                                 </button>
                                {USER_PERMISSIONS.deleteCity && (
                                  <button 
                                    onClick={() => handleDeleteCityRequest(city.id)} 
                                    className="text-red-500 hover:bg-red-50 p-2 rounded-lg"
                                    title="حذف المدينة"
                                  >
                                    <Trash2 size={20} />
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </>
              )}
            </>
          )}

        {appSection === 'tasks' && (
          <div className="animate-in fade-in">
            <div className="flex gap-2 bg-gray-200 p-1 rounded-xl mb-6 max-w-fit overflow-x-auto">
              <button 
                className={`px-6 py-2 rounded-lg font-bold transition whitespace-nowrap ${tasksSubSection === 'myTasks' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-600 hover:bg-gray-300'}`}
                onClick={() => setTasksSubSection('myTasks')}
              >
                مهامي
              </button>
              {CURRENT_USER.role === 'manager' && (
                <button 
                  className={`px-6 py-2 rounded-lg font-bold transition whitespace-nowrap ${tasksSubSection === 'employeeTasks' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-600 hover:bg-gray-300'}`}
                  onClick={() => setTasksSubSection('employeeTasks')}
                >
                  مهام الموظفين
                </button>
              )}
              {CURRENT_USER.role === 'manager' && (
                <button 
                  className={`px-6 py-2 rounded-lg font-bold transition whitespace-nowrap ${tasksSubSection === 'recurringTasks' ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-600 hover:bg-gray-300'}`}
                  onClick={() => setTasksSubSection('recurringTasks')}
                >
                  المهام المتكررة
                </button>
              )}
            </div>

            {tasksSubSection === 'myTasks' && renderTaskDashboard(CURRENT_USER)}

            {tasksSubSection === 'employeeTasks' && CURRENT_USER.role === 'manager' && (
              selectedTaskEmployee ? (
                <div>
                  <button onClick={() => setSelectedTaskEmployee(null)} className="flex items-center gap-2 text-indigo-600 font-medium mb-6 hover:text-indigo-800 transition">
                    <ChevronRight size={20} /> العودة لقائمة الموظفين
                  </button>
                  {renderTaskDashboard(selectedTaskEmployee)}
                </div>
              ) : (
                <div className="animate-in fade-in">
                  <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2"><Users size={24} className="text-indigo-600"/> مهام الموظفين</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {EMPLOYEES.filter(emp => emp.id !== CURRENT_USER.id).map(emp => (
                      <div key={emp.id} onClick={() => setSelectedTaskEmployee(emp)} className="bg-white p-5 rounded-xl shadow-sm border border-gray-100 hover:border-indigo-500 hover:shadow-md cursor-pointer transition flex items-center gap-4 group">
                        <div className="bg-indigo-50 p-3 rounded-full text-indigo-600 group-hover:bg-indigo-100 transition"><User size={24}/></div>
                        <div className="font-bold text-lg text-gray-800">{emp.name}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )
            )}

            {tasksSubSection === 'recurringTasks' && CURRENT_USER.role === 'manager' && (
              <div className="animate-in fade-in">
                <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2"><Repeat size={24} className="text-indigo-600"/> إدارة المهام المتكررة</h2>
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                     <div>
                       <label className="block text-sm font-bold text-gray-700 mb-1">تصفية حسب اليوم</label>
                       <select className="w-full p-3 rounded-lg border outline-none focus:border-indigo-500 bg-gray-50">
                         <option value="">جميع الأيام</option>
                         <option value="0">الأحد</option><option value="1">الإثنين</option><option value="2">الثلاثاء</option>
                         <option value="3">الأربعاء</option><option value="4">الخميس</option><option value="5">الجمعة</option><option value="6">السبت</option>
                       </select>
                     </div>
                     <div>
                       <label className="block text-sm font-bold text-gray-700 mb-1">تصفية حسب الموظف</label>
                       <select className="w-full p-3 rounded-lg border outline-none focus:border-indigo-500 bg-gray-50">
                         <option value="">جميع الموظفين</option>
                         {EMPLOYEES.map(emp => <option key={emp.id} value={emp.id}>{emp.name}</option>)}
                       </select>
                     </div>
                   </div>

                   <div className="space-y-4">
                     {recurringTasks.map(rt => {
                        const empName = EMPLOYEES.find(e => e.id === rt.employeeId)?.name;
                        const daysMap = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
                        const daysStr = rt.daysOfWeek.map(d => daysMap[parseInt(d)]).join('، ');
                        return (
                          <div key={rt.id} className="p-4 border rounded-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:shadow-sm transition">
                            <div>
                              <h4 className="font-bold text-lg">{rt.title}</h4>
                              <p className="text-gray-600 text-sm mt-1">{rt.details}</p>
                              <div className="flex gap-4 mt-2 text-sm text-gray-500">
                                <span className="flex items-center gap-1"><User size={14}/> {empName}</span>
                                <span className="flex items-center gap-1"><Repeat size={14}/> {daysStr}</span>
                              </div>
                            </div>
                            <button onClick={() => handleDeleteRecurringTask(rt.id)} className="bg-red-50 text-red-600 px-4 py-2 rounded-lg font-bold hover:bg-red-100 transition whitespace-nowrap">إلغاء التكرار</button>
                          </div>
                        )
                     })}
                     {recurringTasks.length === 0 && <div className="text-center text-gray-500 py-6">لا توجد مهام متكررة مطابقة للبحث.</div>}
                   </div>
                </div>
              </div>
            )}
          </div>
        )}

        </main>
      </div>

      {/* --- Modals --- */}
      
      {isScheduleModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-sm overflow-hidden shadow-xl animate-in zoom-in-95">
            <div className="p-4 border-b bg-blue-50 flex justify-between items-center text-blue-800">
              <h3 className="text-xl font-bold flex items-center gap-2"><Clock size={20}/> جدولة الرسالة</h3>
              <button onClick={() => setIsScheduleModalOpen(false)} className="text-blue-500 hover:text-blue-800 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={(e) => {
              e.preventDefault();
              executeSendWhatsapp(true, new FormData(e.target).get('scheduleDate'));
            }} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">تاريخ ووقت الإرسال المجدول</label>
                <input required name="scheduleDate" type="datetime-local" className="w-full p-3 rounded-lg border outline-none focus:ring-2 focus:ring-blue-500 text-left" dir="ltr" />
              </div>
              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700">تأكيد الجدولة</button>
                <button type="button" onClick={() => setIsScheduleModalOpen(false)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isAddCustomerOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-xl animate-in zoom-in-95">
            <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
              <h3 className="text-xl font-bold">إضافة زبون جديد</h3>
              <button onClick={() => setIsAddCustomerOpen(false)} className="text-gray-500 hover:text-gray-800 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={handleAddCustomer} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">اسم الزبون</label>
                <input required name="name" type="text" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">رقم الهاتف</label>
                <input required name="phone" type="tel" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none text-left" dir="ltr" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">العنوان النصي</label>
                <input required name="address" type="text" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">رابط الموقع (Google Maps)</label>
                <input name="locationLink" type="url" placeholder="https://maps.google.com/..." className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none text-left" dir="ltr" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">المدينة (يمكن اختيار أكثر من مدينة)</label>
                <div className="max-h-32 overflow-y-auto border rounded-lg p-3 bg-gray-50 grid grid-cols-2 gap-2">
                  {cities.map(city => (
                    <label key={city.id} className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" name="cityIds" value={city.id} className="w-4 h-4 text-blue-600 rounded" />
                      <span>{city.name}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700">حفظ الزبون</button>
                <button type="button" onClick={() => setIsAddCustomerOpen(false)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isAddCityOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-xl animate-in zoom-in-95">
             <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
              <h3 className="text-xl font-bold">إضافة مدينة جديدة</h3>
              <button onClick={() => setIsAddCityOpen(false)} className="text-gray-500 hover:text-gray-800 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={handleAddCity} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">اسم المدينة</label>
                <input required name="name" type="text" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none" />
              </div>
              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700">حفظ المدينة</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {deleteCityTransfer && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-xl animate-in zoom-in-95">
             <div className="p-4 border-b bg-red-50 flex justify-between items-center text-red-700">
              <h3 className="text-xl font-bold flex items-center gap-2"><AlertTriangle size={20}/> تنبيه هام</h3>
              <button onClick={() => setDeleteCityTransfer(null)} className="text-red-500 hover:text-red-800 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={handleTransferAndDeleteCity} className="p-6 space-y-4">
              <p className="text-gray-700">
                لا يمكن حذف هذه المدينة لاحتوائها على <strong>{deleteCityTransfer.affectedCustomers.length}</strong> زبائن. يرجى اختيار مدينة بديلة لتحويل الزبائن إليها:
              </p>
              <div>
                <select required name="newCityId" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-red-500 outline-none bg-gray-50">
                  <option value="">-- اختر المدينة البديلة --</option>
                  {cities.filter(c => c.id !== deleteCityTransfer.cityId).map(city => (
                    <option key={city.id} value={city.id}>{city.name}</option>
                  ))}
                </select>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-red-600 text-white py-3 rounded-lg font-bold hover:bg-red-700">تحويل وحذف</button>
                <button type="button" onClick={() => setDeleteCityTransfer(null)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isAddReportOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-xl animate-in zoom-in-95">
             <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
              <h3 className="text-xl font-bold">إضافة تقرير للزبون</h3>
              <button onClick={() => setIsAddReportOpen(false)} className="text-gray-500 hover:text-gray-800 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={handleAddReport} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">عنوان التقرير</label>
                <input required name="title" type="text" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">محتوى التقرير</label>
                <textarea required name="content" rows="5" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-blue-500 outline-none resize-none"></textarea>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700">حفظ التقرير</button>
                <button type="button" onClick={() => setIsAddReportOpen(false)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isAddTaskOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-xl animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b bg-gray-50 flex justify-between items-center">
              <h3 className="text-xl font-bold">إضافة مهمة جديدة</h3>
              <button onClick={() => setIsAddTaskOpen(false)} className="text-gray-500 hover:text-gray-800 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={handleAddTask} className="p-6 space-y-4">
              {CURRENT_USER?.role === 'manager' && tasksSubSection !== 'myTasks' && (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">تعيين إلى الموظف</label>
                  <select name="employeeId" required className="w-full p-3 rounded-lg border outline-none focus:ring-2 focus:ring-indigo-500 bg-gray-50">
                    {EMPLOYEES.map(emp => <option key={emp.id} value={emp.id} selected={selectedTaskEmployee?.id === emp.id}>{emp.name}</option>)}
                  </select>
                </div>
              )}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">عنوان المهمة</label>
                <input required name="title" type="text" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">التفاصيل</label>
                <textarea required name="details" rows="3" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none resize-none"></textarea>
              </div>
              
              <div className="border-t pt-4">
                <label className="flex items-center gap-2 mb-3 cursor-pointer w-max">
                  <input type="checkbox" name="isRecurring" id="isRecurringCb" className="w-4 h-4 text-indigo-600 rounded" onChange={(e) => {
                    document.getElementById('recurringOptions').style.display = e.target.checked ? 'block' : 'none';
                    document.getElementById('singleDateOption').style.display = e.target.checked ? 'none' : 'block';
                  }}/>
                  <span className="font-bold text-gray-700">مهمة متكررة أسبوعياً؟</span>
                </label>

                <div id="singleDateOption" className="mb-4">
                  <label className="block text-sm font-bold text-gray-700 mb-1">تاريخ المهمة</label>
                  <input name="date" type="date" defaultValue={taskDateFilter} className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none text-left" dir="ltr" />
                </div>

                <div id="recurringOptions" style={{display: 'none'}} className="mb-4 bg-indigo-50 p-4 rounded-xl border border-indigo-100">
                  <label className="block text-sm font-bold text-indigo-800 mb-2">اختر أيام التكرار:</label>
                  <div className="flex flex-wrap gap-2">
                    {[
                      { val: '0', label: 'الأحد' }, { val: '1', label: 'الإثنين' }, { val: '2', label: 'الثلاثاء' },
                      { val: '3', label: 'الأربعاء' }, { val: '4', label: 'الخميس' }, { val: '5', label: 'الجمعة' }, { val: '6', label: 'السبت' }
                    ].map(day => (
                      <label key={day.val} className="flex items-center gap-1 bg-white px-3 py-1.5 rounded-lg border cursor-pointer hover:bg-indigo-50 transition shadow-sm">
                        <input type="checkbox" name="daysOfWeek" value={day.val} className="w-4 h-4 text-indigo-600 rounded" />
                        <span className="text-sm">{day.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="border-t pt-4">
                <label className="flex items-center gap-2 mb-3 cursor-pointer w-max">
                  <input type="checkbox" name="isFullDay" defaultChecked className="w-4 h-4 text-indigo-600 rounded" onChange={(e) => {
                    document.getElementById('timeOptions').style.display = e.target.checked ? 'none' : 'flex';
                  }}/>
                  <span className="font-bold text-gray-700">مهمة طوال اليوم (لا يوجد وقت محدد)</span>
                </label>
                <div id="timeOptions" style={{display: 'none'}} className="gap-4">
                  <div className="flex-1">
                    <label className="block text-sm text-gray-500 mb-1">من الساعة</label>
                    <input name="startTime" type="time" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none text-left" dir="ltr" />
                  </div>
                  <div className="flex-1">
                    <label className="block text-sm text-gray-500 mb-1">إلى الساعة</label>
                    <input name="endTime" type="time" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none text-left" dir="ltr" />
                  </div>
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-indigo-600 text-white py-3 rounded-lg font-bold hover:bg-indigo-700 transition">إضافة المهمة</button>
                <button type="button" onClick={() => setIsAddTaskOpen(false)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300 transition">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {taskActionModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-xl animate-in zoom-in-95">
            <div className={`p-4 border-b flex justify-between items-center text-white ${
              taskActionModal.type === 'complete' ? 'bg-green-600' :
              taskActionModal.type === 'delay' ? 'bg-yellow-500' :
              taskActionModal.type === 'cancel' ? 'bg-red-600' : 'bg-blue-600'
            }`}>
              <h3 className="text-xl font-bold flex items-center gap-2">
                {taskActionModal.type === 'complete' && <><CheckCircle size={20}/> إنجاز المهمة</>}
                {taskActionModal.type === 'delay' && <><Clock size={20}/> تأجيل المهمة</>}
                {taskActionModal.type === 'cancel' && <><XCircle size={20}/> إلغاء المهمة</>}
                {taskActionModal.type === 'reschedule' && <><CalendarDays size={20}/> إعادة رفع المهمة (معلقة)</>}
              </h3>
              <button onClick={() => setTaskActionModal(null)} className="text-white hover:text-gray-200 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={handleTaskAction} className="p-6 space-y-4">
              
              {taskActionModal.type === 'complete' && (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">تفاصيل الإنجاز (إجباري)</label>
                  <textarea required name="completionDetails" rows="4" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-green-500 outline-none resize-none" placeholder="اكتب ما تم إنجازه..."></textarea>
                </div>
              )}

              {taskActionModal.type === 'cancel' && (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">سبب الإلغاء (إجباري)</label>
                  <textarea required name="cancelReason" rows="4" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-red-500 outline-none resize-none" placeholder="لماذا تم إلغاء المهمة؟"></textarea>
                </div>
              )}

              {(taskActionModal.type === 'delay' || taskActionModal.type === 'reschedule') && (
                <>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">التاريخ الجديد</label>
                    <input required name="newDate" type="date" defaultValue={taskActionModal.task.date} className="w-full p-3 rounded-lg border outline-none text-left" dir="ltr" />
                  </div>
                  <div className="border-y py-3 my-2">
                    <label className="flex items-center gap-2 mb-3 cursor-pointer w-max">
                      <input type="checkbox" name="isFullDay" defaultChecked={taskActionModal.task.isFullDay} className="w-4 h-4 text-blue-600 rounded" onChange={(e) => {
                        document.getElementById('actionTimeOptions').style.display = e.target.checked ? 'none' : 'flex';
                      }}/>
                      <span className="font-bold text-gray-700">طوال اليوم</span>
                    </label>
                    <div id="actionTimeOptions" style={{display: taskActionModal.task.isFullDay ? 'none' : 'flex'}} className="gap-4">
                      <div className="flex-1">
                        <label className="block text-sm text-gray-500 mb-1">من</label>
                        <input name="newStartTime" type="time" defaultValue={taskActionModal.task.startTime} className="w-full p-3 rounded-lg border outline-none text-left" dir="ltr" />
                      </div>
                      <div className="flex-1">
                        <label className="block text-sm text-gray-500 mb-1">إلى</label>
                        <input name="newEndTime" type="time" defaultValue={taskActionModal.task.endTime} className="w-full p-3 rounded-lg border outline-none text-left" dir="ltr" />
                      </div>
                    </div>
                  </div>
                  {taskActionModal.type === 'delay' && (
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-1">سبب التأجيل (إجباري)</label>
                      <textarea required name="delayReason" rows="3" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-yellow-500 outline-none resize-none" placeholder="لماذا تم تأجيل المهمة؟"></textarea>
                    </div>
                  )}
                </>
              )}

              <div className="pt-4 flex gap-3">
                <button type="submit" className={`flex-1 text-white py-3 rounded-lg font-bold transition shadow-sm ${
                  taskActionModal.type === 'complete' ? 'bg-green-600 hover:bg-green-700' :
                  taskActionModal.type === 'delay' ? 'bg-yellow-500 hover:bg-yellow-600' :
                  taskActionModal.type === 'cancel' ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'
                }`}>حفظ التغييرات</button>
                <button type="button" onClick={() => setTaskActionModal(null)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300 transition shadow-sm">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isAddReminderOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden shadow-xl animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b bg-amber-50 flex justify-between items-center text-amber-800">
              <h3 className="text-xl font-bold flex items-center gap-2"><Bell size={20}/> إضافة تذكير جديد</h3>
              <button onClick={() => setIsAddReminderOpen(false)} className="text-amber-500 hover:text-amber-800 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={handleAddReminder} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">اسم/عنوان التذكير</label>
                <input required name="title" type="text" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-amber-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">التفاصيل</label>
                <textarea required name="details" rows="3" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-amber-500 outline-none resize-none"></textarea>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">الموظفين المشمولين بالتذكير</label>
                <div className="max-h-32 overflow-y-auto border rounded-lg p-3 bg-gray-50 grid grid-cols-2 gap-2">
                  {EMPLOYEES.map(emp => (
                    <label key={emp.id} className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" name="employeeIds" value={emp.id} className="w-4 h-4 text-amber-600 rounded focus:ring-amber-500" />
                      <span className="text-sm">{emp.name}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="border border-amber-200 bg-amber-50 p-3 rounded-xl">
                 <label className="block text-sm font-bold text-amber-800 mb-2">نوع إنجاز التذكير:</label>
                 <div className="space-y-2">
                   <label className="flex items-center gap-2 cursor-pointer">
                     <input type="radio" name="completionType" value="single" defaultChecked className="text-amber-600 focus:ring-amber-500"/>
                     <span className="text-sm font-bold text-amber-900">إنجاز فردي (يُنجز من موظف واحد وينتهي للجميع)</span>
                   </label>
                   <label className="flex items-center gap-2 cursor-pointer">
                     <input type="radio" name="completionType" value="all" className="text-amber-600 focus:ring-amber-500"/>
                     <span className="text-sm font-bold text-amber-900">إنجاز جماعي (كل موظف ينجزه من حسابه الخاص)</span>
                   </label>
                 </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
                 <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">تاريخ التذكير</label>
                  <input required name="date" type="date" defaultValue={new Date().toISOString().split('T')[0]} className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-amber-500 outline-none text-left" dir="ltr" />
                 </div>
                 <div className="flex flex-col justify-center mt-6">
                  <label className="flex items-center gap-2 cursor-pointer w-max">
                    <input type="checkbox" name="isFullDay" defaultChecked className="w-4 h-4 text-amber-600 rounded" onChange={(e) => {
                      document.getElementById('reminderTimeOptions').style.display = e.target.checked ? 'none' : 'flex';
                    }}/>
                    <span className="font-bold text-gray-700 text-sm">تذكير طوال اليوم</span>
                  </label>
                 </div>
              </div>

              <div id="reminderTimeOptions" style={{display: 'none'}} className="gap-4">
                <div className="flex-1">
                  <label className="block text-sm text-gray-500 mb-1">من الساعة</label>
                  <input name="startTime" type="time" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-amber-500 outline-none text-left" dir="ltr" />
                </div>
                <div className="flex-1">
                  <label className="block text-sm text-gray-500 mb-1">إلى الساعة</label>
                  <input name="endTime" type="time" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-amber-500 outline-none text-left" dir="ltr" />
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-amber-500 text-white py-3 rounded-lg font-bold hover:bg-amber-600 transition">إنشاء التذكير</button>
                <button type="button" onClick={() => setIsAddReminderOpen(false)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300 transition">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {reminderCompletionModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden shadow-xl animate-in zoom-in-95">
            <div className="p-4 border-b bg-green-600 flex justify-between items-center text-white">
              <h3 className="text-xl font-bold flex items-center gap-2"><CheckCircle size={20}/> إنجاز التذكير</h3>
              <button onClick={() => setReminderCompletionModal(null)} className="text-white hover:text-gray-200 text-2xl leading-none">&times;</button>
            </div>
            <form onSubmit={handleCompleteReminder} className="p-6 space-y-4">
              <p className="text-gray-600 text-sm mb-2">أنت تقوم بإنجاز التذكير: <strong className="text-gray-800">{reminderCompletionModal.reminder.title}</strong></p>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">تفاصيل الإنجاز (إجباري)</label>
                <textarea required name="completionDetails" rows="4" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-green-500 outline-none resize-none" placeholder="اكتب ما تم إنجازه بخصوص هذا التذكير..."></textarea>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 transition shadow-sm">حفظ الإنجاز</button>
                <button type="button" onClick={() => setReminderCompletionModal(null)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300 transition shadow-sm">إلغاء</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isUserModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl w-full max-w-3xl overflow-hidden shadow-xl animate-in zoom-in-95 max-h-[90vh] flex flex-col">
            <div className="p-4 border-b bg-indigo-50 flex justify-between items-center text-indigo-900 shrink-0">
              <h3 className="text-xl font-bold flex items-center gap-2"><User size={20}/> {editingUser ? 'تعديل بيانات المستخدم' : 'إضافة مستخدم جديد'}</h3>
              <button onClick={() => setIsUserModalOpen(false)} className="text-indigo-500 hover:text-indigo-800 text-2xl leading-none">&times;</button>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              <form id="userForm" onSubmit={handleSaveUser} className="space-y-6">
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">اسم المستخدم</label>
                    <input required name="name" type="text" defaultValue={editingUser?.name || ''} className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none bg-gray-50" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">رقم الهاتف</label>
                    <input required name="phone" type="tel" defaultValue={editingUser?.phone || ''} className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none text-left bg-gray-50" dir="ltr" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">كلمة المرور</label>
                    <input required name="password" type="text" defaultValue={editingUser?.password || ''} className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none bg-gray-50" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1">فئة المستخدم</label>
                    <select required name="role" defaultValue={editingUser?.role || 'employee'} className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-indigo-500 outline-none bg-gray-50">
                      <option value="manager">مشرف</option>
                      <option value="employee">موظف</option>
                    </select>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <label className="block text-lg font-bold text-indigo-800 mb-4 flex items-center gap-2"><Shield size={20}/> الصلاحيات الممنوحة</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {PERMISSIONS_LIST.map(perm => (
                      <label key={perm.id} className="flex items-start gap-2 p-2 hover:bg-indigo-50 rounded-lg cursor-pointer border border-transparent hover:border-indigo-100 transition">
                        <input 
                          type="checkbox" 
                          name="permissions" 
                          value={perm.id} 
                          defaultChecked={editingUser ? editingUser.permissions.includes(perm.id) : false}
                          className="mt-1 w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500" 
                        />
                        <span className="text-sm text-gray-700 font-medium">{perm.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </form>
            </div>
            <div className="p-4 border-t bg-gray-50 flex gap-3 shrink-0">
              <button type="submit" form="userForm" className="flex-1 bg-indigo-600 text-white py-3 rounded-lg font-bold hover:bg-indigo-700 transition shadow-sm">حفظ المستخدم</button>
              <button type="button" onClick={() => setIsUserModalOpen(false)} className="flex-1 bg-gray-200 text-gray-800 py-3 rounded-lg font-bold hover:bg-gray-300 transition shadow-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}